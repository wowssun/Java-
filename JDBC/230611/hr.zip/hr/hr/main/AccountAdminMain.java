package hr.main;

import java.util.Scanner;

import hr.dao.EmployeeDAO;
import hr.dao.HistoryDAO;
import hr.dao.ReviewDAO;
import hr.dao.SalaryInfoDAO;
import hr.dao.SalaryPaymentDAO;
import hr.dao.WorkDAO;
import hr.dao.YearDAO;
import hr.vo.EmployeeVO;

public class AccountAdminMain {

	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryInfoDAO sdao;
	private SalaryPaymentDAO spdao;
	private ReviewDAO rdao;
	private EmployeeVO evo;

	public void adManage() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            MENU           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 급여 정보  2. 급여 지급내역  ");
		System.out.println("  3. 메인메뉴   4. 시스템 종료  ");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
	    System.out.println("--------------------------------");
	   	System.out.println("    1번 ~ 4번을 선택해주세요.   ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	}
	
	public void salInfo() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 급여 정보 등록  2. 급여 정보 전체");
		System.out.println("  3. 급여 관리 메뉴  ");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("    1번 ~ 3번을 선택해주세요.   ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
		
	}
	
	public void salInfoWrite() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 등록      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 급여 정보 등록을 위한 정보를 입력해주세요.>");
		System.out.println();
		System.out.println("  1.직원 번호 >>");
		System.out.println("  2.은행 이름 >>");
		System.out.println("  3.예금주 >>");
		System.out.println("  4.계좌번호 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      등록이 완료되었습니다.     ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("    정보 등록에 실패했습니다.    ");
		System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public void salInfoModify(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 수정      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.은행이름  >>");
		System.out.println("  2.예금주 >>");
		System.out.println("  3.계좌번호 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      정보가 수정되었습니다.    ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("      수정에 실패했습니다.      ");
	   	System.out.println("--------------------------------");
		System.out.println();
	
		
	}
	
	public void salInfoRemove(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 정보 삭제      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("         삭제되었습니다.          ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         취소되었습니다.          ");
	   	System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public void salPayWrite() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    급여 지급 내역 등록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 급여 정보 등록을 위한 정보를 입력해주세요.>");
		System.out.println();
		System.out.println("  1.직원 번호 >>");
		System.out.println("  2.지급일시 >>");
		System.out.println("  3.기본급 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      등록이 완료되었습니다.     ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("    정보 등록에 실패했습니다.    ");
		System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public void salPayModify(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여 지급 내역 수정   ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.지급일시 >>");
		System.out.println("  2.기본급 >>");
		System.out.println("  3.상여금 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("      정보가 수정되었습니다.    ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("      수정에 실패했습니다.      ");
	   	System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public void salPayRemove(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여 지급 내역 삭제   ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("         삭제되었습니다.          ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         취소되었습니다.          ");
	   	System.out.println("--------------------------------");
		System.out.println();
		
	}
	
//	System.out.println("--------------------------------");
//	System.out.println("  💡 시스템을 종료하시겠습니까? ( Y | N )");
//	System.out.println("  💡 >> ");
//	System.out.println("--------------------------------");
//  System.out.println("       1번이나 2번을 선택하세요.     ");
//  System.out.println("--------------------------------");
	
}
