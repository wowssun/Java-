package memo.resources;

public class Deco {

	public static void main(String[] args) {
//		System.out.print("─│┌┐└┘");
		System.out.println("┌───────────────────────────────┐");
        System.out.println("    MEMBER MANAGEMENT SYSTEM   │");
        System.out.println("└───────────────────────────────┘");
        System.out.println();
        
       
        System.out.print("💡번호를 선택해주세요 >>> ");
        
        System.out.println(" ───────────────────────────────");
        
       String mid = "aaa";
       String name = "ayo";
       int age = 20;
       String phone = "010-7878-7878";
       String date = "2023-05-24";
       
       System.out.println("no, mid, memo, date");
        
        
        System.out.println("───────────────────────────────────────────────");
        System.out.println(" 아이디 | 이름 | 나이 |   전화번호  | 가입일자 ");
        System.out.println("───────────────────────────────────────────────");
        System.out.println("aaa     |ayo   |20    |010-7878-7878|2023-05-24");
        System.out.printf("%8s|%6s|%6d|%13s|%10s%n",mid,name,age,phone,date);
//        System.out.println("bbb|bbb|11|010-2222-2222|2023-05-24");
//        System.out.println("ccc|ccc|12|010-3333-3333|2023-05-24");
//        System.out.println("ddd|ddd|13|010-4444-4444|2023-05-24");
//        System.out.println("eee|eee|14|010-5555-5555|2023-05-24");
//        System.out.println("admin|admin|100|1111|2023-05-27");
//      
        int a = 1;
        String b = "aaa";
        String c = "안녕하세요";
        String d = "2023-05-28";
        
        
        System.out.println("─────────────────────────────────────────────────────────────────────");
        System.out.println(" no.| 이름 |                메모                         | 작성일자 ");
        System.out.println("─────────────────────────────────────────────────────────────────────");
        System.out.println("1   |aaa   |안녕하세요                                   |2023-05-28");
        System.out.printf("%4d|%6s|%40s|%10s%n",a,b,c,d);
        
       
        
	}

}
