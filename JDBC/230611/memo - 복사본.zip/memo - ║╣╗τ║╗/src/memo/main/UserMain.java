package memo.main;

import java.util.Scanner;

import memo.dao.MemberDAO;
import memo.util.DBConn;
import memo.vo.MemberVO;

public class UserMain {
	private Scanner sc;
	private int input;
	private MemoMain memi;
	private MemberMain mbmi;
	private MemberDAO mdao;
	private MemberVO mvo;
	
	public UserMain() {
		sc = new Scanner(System.in);
		mdao = new MemberDAO();
		memi = new MemoMain();
		mbmi = new MemberMain();
	}
	
	public void menu() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│    MEMBER MANAGEMENT SYSTEM   │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.println(" 1. 내 정보 보기");
		System.out.println(" 2. 한줄 메모 게시판으로 이동하기");
		System.out.println(" 3. 메인 페이지로 이동하기");
		System.out.println(" 4. 프로그램 종료");
		System.out.println();
		System.out.print("💡번호를 선택해주세요 >>> ");
		input = sc.nextInt();
		System.out.println();
		
		switch (input) {
			case 1 : System.out.println(" ──────────────────────────────────");
					 System.out.println("  🔎내 정보 페이지로 이동합니다🔍 ");       // 나의 정보 보기 페이지로 이동하기 
					 System.out.println(" ──────────────────────────────────");
					 System.out.println();
					 info(); 	break;  
			case 2 : System.out.println(" ───────────────────────────────────");
					 System.out.println("  한 줄 메모 게시판으로 이동합니다. ");	
					 System.out.println(" ───────────────────────────────────");
					 System.out.println();
					 memi.menu(); break;//  한줄 메모 게시판으로 이동
			case 3 : System.out.println(" ──────────────────────────────"); 
					 System.out.println("   로그인 페이지로 이동합니다. ");
					 System.out.println(" ──────────────────────────────"); 
					 System.out.println();
			         mbmi.menu();
			case 4 :System.out.println(" ───────────────────────────────");
					System.out.println("   ❌ 프로그램을 종료합니다 ❌ ");
					System.out.println(" ───────────────────────────────");
					sc.close();
					DBConn.close();		// connection close. 시스템이 끝나면 끝나지만 명시적으로 하기 위해
					System.exit(0);  // 정상종료          
		}
	} // menu end
	
	public void info() {   // 1. 내가 로그인한 아이디 값을 매개변수로 하는 info 메서드
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│            MY INFO            │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		
		String id = mbmi.id;
	
		MemberVO mvo = mdao.select(id);                                //2. 입력받은 매개변수를 select 로 저장한다.// 리턴값을 받는다. mvo로 받아왔다.
		 									// 호출받은 값을 MembeVO에 저장을 한 것
		//4. 화면에 출력한다.
		if(mvo!=null) {   // mvo에 값이 있다면 
			System.out.println("┌───────────────────────────────┐");
			System.out.println("   아이디 :" + mvo.getMid());  // mvo에 있는 값을 get 가져온다.
			System.out.println("   이름 : " + mvo.getMname());
			System.out.println("   나이 :  " + mvo.getMage());
			System.out.println("   전화번호 : "+ mvo.getMphone());
			System.out.println("   가입일자 : " + mvo.getMdate());
			System.out.println("└───────────────────────────────┘");
			System.out.println(" 1. 정보수정   2. 탈퇴하기  3. 메인메뉴");
			System.out.println();
	
			System.out.print("💡번호를 선택해주세요 >>> ");
			int num = sc.nextInt();
			System.out.println();
			
			switch(num) {
				case 1: modify(mvo); break;   //  호출을 할때 매개변수 확인하기, 호출한 메서드와 같은 ㅎㅇ태다.
				case 2: remove(); break;
				case 3: menu();
				default : System.out.println(" 1 ~ 3을 선택해주세요.");
				System.out.println();
				new UserMain().menu();   // 회원정보 메뉴 표시
				}
			
			}else {
		    System.out.println(" ───────────────────────────────────");
			System.out.println("   해당 아이디가 존재하지 않습니다. ");
			System.out.println();
			System.out.println("         메뉴로 이동합니다          ");
			System.out.println(" ───────────────────────────────────");
			System.out.println();
			}
	
		menu();	
	} // info end
	
	
	public void modify(MemberVO mvo) {  // 정보 수정하기
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│         MEMBER UPDATE         │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.print("💡이름을 수정하세요 >>> ");
		mvo.setMname(sc.next());
		System.out.print("💡전화번호를 수정하세요 >>> ");
		mvo.setMphone(sc.next());
		
			if(mdao.update(mvo)) {
				System.out.println();
				System.out.println("────────────────────────────");
				System.out.println("  회원정보가 수정되었습니다.");
				System.out.println("────────────────────────────");
			}else {
				System.out.println("──────────────────────────────");
				System.out.println(" 회원정보 수정에 실패했습니다.");
				System.out.println("──────────────────────────────");
			}
			info();
		
		
	} // modify end
	public void remove() {  // 탈퇴하기
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│         MEMBER DELETE         │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		
		System.out.print(" 💡회원 탈퇴하시겠습니까?( Y | N ) >>> ");  // 의사확인
		String answer = sc.next();
		
		String mid = mbmi.id;
		
		  if(answer.equalsIgnoreCase("Y")) {  // equalsIgnoreCase는 대소문자 구분없이 사용할 수 있다.
			 
			  if(mdao.delete(mid)){	
				    System.out.println(" ────────────────────────────");
			  		System.out.println("    탈퇴가 완료되었습니다.   "); 	// 반환되는 값을 받아서  // dao에 넘긴다.
			        System.out.println(" 로그인 페이지로 이동합니다. ");
			        System.out.println(" ────────────────────────────");
			        mbmi.login();
			        
			 	}else {
			 	 System.out.println(" ──────────────────────");	
				 System.out.println("  삭제에 실패했습니다. ");
				 System.out.println(" ──────────────────────");
			 	}
	  		}else if(answer.equalsIgnoreCase("N")) {
	  			System.out.println(" ──────────────────────");
	    	  	System.out.println(" 삭제가 취소되었습니다.");
	    	  	System.out.println(" ──────────────────────");
	    	  	menu();
	    	  	
	  		}else {
    	        System.out.println("Y나 N을 선택해주세요.");
        }	
		  System.out.println();	
	} // remove end
	
}// class end
