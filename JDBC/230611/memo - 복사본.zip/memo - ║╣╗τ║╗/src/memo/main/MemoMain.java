package memo.main;

import java.util.List;
import java.util.Scanner;

import memo.dao.MemoDAO;
import memo.vo.MemberVO;
import memo.vo.MemoVO;

public class MemoMain {
	private Scanner sc;
	private int input;
	private MemoVO mevo;
	private MemoDAO meda;
	private MemberMain mbmi;
	
	public MemoMain() {
		sc = new Scanner(System.in);
		meda = new MemoDAO();
		mevo = new MemoVO();
		

	}

	public void menu() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│     MEMO MANAGEMENT SYSTEM    │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.println("1. 한 줄 메모 작성하기");
		System.out.println("2. 전체 목록 보기");
		System.out.println("3. 내 메모 목록 보기");
		System.out.println("4. 회원 메뉴 페이지로 가기");
		System.out.println();
		System.out.print("💡번호를 선택해주세요 >>> ");
		input = sc.nextInt();
		System.out.println();

		switch (input) {
		case 1:
			write();
			break;
		case 2:
			list();
			break;
		case 3:
			mylist();
			break;
		case 4:
			System.out.println(" ───────────────────────────────");
			System.out.println("      회원 메뉴로 이동합니다.   ");
			System.out.println(" ───────────────────────────────");
			System.out.println();
			new UserMain().menu();
			break;

		default:
			System.out.println("     다시 선택해주세요. 1 ~ 4  ");
			System.out.println();
			menu();
		}

	} // menu end

	public void write() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│             MEMO              │");
		System.out.println("└───────────────────────────────┘");
		System.out.println("        메모를 작성하세요        ");
		System.out.println();
		System.out.print(">>> ");
		String memo = sc.next();
		System.out.println();
		
//		System.out.print("메모를 작성하시겠습니까? ( Y | N )>>> ");
//		String yesno = sc.nextLine();
		
		MemoVO mevo = new MemoVO();
		mevo.setMemo(memo);
		mevo.setMid(mbmi.id);
		System.out.println();
		
//		if (yesno.equalsIgnoreCase("y")) {
			if(meda.insert(mevo)) {
				System.out.println(" ───────────────────────────────");
				System.out.println("    메모 작성이 완료되었습니다. ");
				System.out.println(" ───────────────────────────────");
			}else {
				System.out.println(" ───────────────────────────────");
				System.out.println("    메모 작성에 실패했습니다. ");
				System.out.println(" ───────────────────────────────");
			}
//		} else if (yesno.equalsIgnoreCase("n")) {
//			System.out.println(" ───────────────────────────────");
//			System.out.println("    메모 작성을 취소하셨습니다. ");
//			System.out.println();
//			System.out.println("   메모 시스템으로 돌아갑니다.  ");
//			System.out.println(" ───────────────────────────────");
			
//		}else {
//			System.out.println("Y나 N을 선택해주세요");
//		}
		System.out.println();
		menu();
	} // write end

	// 전체 목록 가져오기
	public void list() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│           MEMO LIST           │");
		System.out.println("└───────────────────────────────┘");

		List<MemoVO> memoList = meda.select();
		// dao에 매개변수가 없는 셀렉트 메서드 호출
		// 반환되는 값을 저장한뒤
		// 화면에 표시

		if (memoList.size() > 0) { // 등록된 게시물이 있다면 화면에 표시

			System.out.println("─────────────────────────────────────────────────────────────────────");
			System.out.println(" no.| 이름 |                메모                         | 작성일자 ");
			System.out.println("─────────────────────────────────────────────────────────────────────");
			for (MemoVO list : memoList) {
				System.out.printf("%4d|%6s| %-40s|%10s%n", list.getMno(), list.getMid(), list.getMemo(),
						list.getRegdate());
				System.out.println();
			}

		} else {
			System.out.println(" ───────────────────────────");
			System.out.println("    등록된 회원이 없습니다. ");
			System.out.println("      메뉴로 이동합니다.    ");
			System.out.println(" ───────────────────────────");
		}
		menu();

	} // list end

	// 내 메모 목록 가져오기
	public void mylist() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│            MY MEMO            │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();

		String id = mbmi.id;

		List<MemoVO> memoList = meda.select(id);

		if (memoList.size() > 0) { // 등록된 게시물이 있다면 화면에 표시
			// for문 이용
//			for(int i = 0 ; i < mvoList.size(); i++) {
//				MemberVO mvo = mvoList.get(i);
//				System.out.println( mvo.getMid()+"|"+ mvo.getMname()+ "|"+mvo.getMage()+ "|"+ mvo.getMphone()+ "|"+ mvo.getMdate());
//	}
			System.out.println("─────────────────────────────────────────────────────────────────────");
			System.out.println(" no.| 이름 |                메모                         | 작성일자 ");
			System.out.println("─────────────────────────────────────────────────────────────────────");
			for (MemoVO list : memoList) {
				System.out.printf("%4d|%6s| %-30s|%10s%n", list.getMno(), list.getMid(), list.getMemo(),list.getRegdate());		
				System.out.println();
				}
				detail();
		} else {
			System.out.println(" ────────────────────────────");
			System.out.println("   작성된 게시물이 없습니다. ");
			System.out.println("      메뉴로 이동합니다.     ");
			System.out.println(" ────────────────────────────");
			menu();
		}
		

	} // list end
	
	public void detail() {
		System.out.println();
		System.out.print("💡조회하고 싶은 메모의 번호를 선택하세요 >>> ");
		int input = sc.nextInt();
		System.out.println();
		
		MemoVO mevo = meda.select(input);
		
		if(mevo !=null) {
			System.out.println("┌──────────────────────────────────┐");
			System.out.println("   번호 : " + mevo.getMno());
			System.out.println("   아이디 :" + mevo.getMid());
			System.out.println("   작성일자 : " + mevo.getRegdate());
			System.out.println("   메모 : " + mevo.getMemo());
			System.out.println("└───────────────────────────────────┘");
			System.out.println(" 1. 메모수정   2. 메모삭제  3. 메모메뉴");
			System.out.println();
			System.out.print("💡번호를 선택해주세요 >>> ");
			int num = sc.nextInt();
			System.out.println();
		
			switch(num) {
			case 1: modify(mevo); break;   //  호출을 할때 매개변수 확인하기, 호출한 메서드와 같은 ㅎㅇ태다.
			case 2: remove(mevo); break;
			case 3: menu();
			default : System.out.println(" 다시 선택해주세요.( 1 ~ 3 )");
			System.out.println();
			}
		}else{
			System.out.println("해당 아이디가 존재하지 않습니다.");
			System.out.println("메뉴로 이동합니다.");
		}			
			
	}  // detail end

    // 메모 수정하기
	public void modify(MemoVO mevo) {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│          MEMO UPDATE          │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.print("💡메모를 수정하세요 >>> ");
		mevo.setMemo(sc.next());
		
		
			if(meda.update(mevo)) {
				System.out.println();
				System.out.println("────────────────────────────");
				System.out.println("    메모가 수정되었습니다.  ");
				System.out.println("────────────────────────────");
			}else {
				System.out.println("──────────────────────────────");
				System.out.println("   메모 수정에 실패했습니다.  ");
				System.out.println("──────────────────────────────");
			}
			menu();
	
	
	
} // modify end

	// 메모 삭제하기
	public void remove(MemoVO mevo) {
		System.out.println();
		System.out.print("💡메모를 삭제하시겠습니까? (Y | N) >>> ");  // 의사확인
		String answer = sc.next();
		System.out.println();
		
		  if(answer.equalsIgnoreCase("Y")) {  // equalsIgnoreCase는 대소문자 구분없이 사용할 수 있다.
			 
			  if(meda.delete(mevo)){	
				    System.out.println(" ────────────────────────");
			  		System.out.println("  삭제가 완료되었습니다. "); 									// 반환되는 값을 받아서  // dao에 넘긴다.
			        System.out.println("   메인으로 이동합니다.  ");
			        System.out.println(" ────────────────────────");
			        
			 	}else {
				 System.out.println("삭제에 실패했습니다.");
			 	}
	  		}else if(answer.equalsIgnoreCase("N")) {
	    	  	System.out.println("삭제가 취소되었습니다.");
	  		}else {
    	        System.out.println("Y나 N을 선택해주세요.");
       }
		  menu();

	}// remove end
	

} // class end
