package memo.main;


import java.util.List;
import java.util.Scanner;

import memo.dao.MemberDAO;
import memo.util.DBConn;
import memo.vo.MemberVO;
public class AdminMain {
	private Scanner sc;
	private int input;
	private MemberDAO mdao;
	private MemberVO mvo;
	
		
	public AdminMain() {
		sc = new Scanner(System.in);
		mdao = new MemberDAO();
	}
	
	public static void main(String []args) {
		AdminMain admin = new AdminMain();
		admin.menu();
	}
				
	public void menu() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│     ADMIN MANAGEMENT SYSTEM   │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.println("1. 회원 목록 확인하기");
		System.out.println("2. 회원 정보 조회하기");
		System.out.println("3. 메인 페이지로 이동하기");
		System.out.println("4. 프로그램 종료");
		System.out.println();
		System.out.print("💡번호를 선택해주세요 >>> ");
		input = sc.nextInt();
		System.out.println();
		
		
		switch(input) {
		case 1 : list(); break;
		case 2 : info(); break;
		case 3 : System.out.println(" ───────────────────────────────");
				 System.out.println("   로그인 페이지로 이동합니다.  ");
				 System.out.println(" ───────────────────────────────");
				 System.out.println();
		         new MemberMain().menu();  break;
		case 4 :System.out.println(" ───────────────────────────────");
				System.out.println("   ❌ 프로그램을 종료합니다 ❌ ");
				System.out.println(" ───────────────────────────────");
				sc.close();
				DBConn.close();		// connection close. 시스템이 끝나면 끝나지만 명시적으로 하기 위해
				System.exit(0);  // 정상종료 
	  default : System.out.println("번호를 다시 선택해주세요. 1 ~ 4");
				System.out.println();
		}
		         menu();		
			         
	} // menu end
	
	// 회원 전체 보기
	public void list() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│          MEMBER LIST          │");
		System.out.println("└───────────────────────────────┘");
		
		List<MemberVO> mvoList = mdao.select(); 
		// dao에 매개변수가 없는 셀렉트 메서드 호출
		// 반환되는 값을 저장한뒤
		//화면에 표시
	
		if(mvoList.size() > 0) {   // 등록된 게시물이 있다면 화면에 표시
			// for문 이용
//			for(int i = 0 ; i < mvoList.size(); i++) {
//				MemberVO mvo = mvoList.get(i);
//				System.out.println( mvo.getMid()+"|"+ mvo.getMname()+ "|"+mvo.getMage()+ "|"+ mvo.getMphone()+ "|"+ mvo.getMdate());
//	}
			System.out.println("───────────────────────────────────────────────");
	        System.out.println(" 아이디 | 이름 | 나이 |   전화번호  | 가입일자");
	        System.out.println("───────────────────────────────────────────────");
			for(MemberVO list : mvoList) {
				System.out.printf("%8s|%6s|%6d|%13s|%10s%n",list.getMid(),list.getMname(),list.getMage(),list.getMphone(),list.getMdate());
				System.out.println();
			}
			
		}else {
			    System.out.println(" ────────────────────────────");
				System.out.println("    등록된 회원이 없습니다.  ");
				System.out.println("      메뉴로 이동합니다.     ");
				System.out.println(" ────────────────────────────");
			}
				menu();

	}
	
	// 회원 한명만 조회
	public void info() {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│    MEMBER MANAGEMENT SYSTEM   │");
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.print("💡조회할 아이디를 입력하세요 >>> ");
		String mid = sc.next();
		
//		mdao.select(mid); // 1. 아이디를 입력받는다.
		
		MemberVO mvo = mdao.select(mid);  //2. 입력받은 매개변수를 select 로 저장한다.// 리턴값을 받는다. mvo로 받아왔다.
		 
		//4. 화면에 출력한다.
		if(mvo !=null) {
		System.out.println("┌──────────────────────────────────┐");
		System.out.println("   회원아이디 :" + mvo.getMid());
		System.out.println("   회원이름 : " + mvo.getMname());
		System.out.println("   회원나이 :  " + mvo.getMage());
		System.out.println("   전화번호 : "+ mvo.getMphone());
		System.out.println("   가입일자 : " + mvo.getMdate());
		System.out.println("└───────────────────────────────────┘");
		System.out.println(" 1. 회원수정   2. 회원 삭제  3. 메뉴");
		System.out.println();

		System.out.print("💡번호를 선택해주세요 >>> ");
		int num = sc.nextInt();
		
		switch(num) {
		case 1: modify(mvo); break;   //  호출을 할때 매개변수 확인하기, 호출한 메서드와 같은 ㅎㅇ태다.
		case 2: remove(mid); break;
		case 3: menu();
		default : System.out.println(" 다시 선택해주세요.( 1 ~ 3 )");
		System.out.println();
		info();   // 회원정보 메뉴 표시
	}
}else {
	System.out.println("해당 아이디가 존재하지 않습니다.");
	System.out.println("메뉴로 이동합니다.");
	menu();
}		
	} // info end
	
	public void modify(MemberVO mvo) {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│          MEMBER UPDATE        │" );
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		System.out.print("💡이름을 수정하세요 >>> ");
		mvo.setMname(sc.next());
		System.out.print("💡전화번호를 수정하세요 >>> ");
		mvo.setMphone(sc.next());					 // 입력받은 값을 바로 membervo에 저장까지 완료
	       
	        boolean result = mdao.update(mvo);       // 반환되는 값을 받아서
		     if(result) {		// dao에 넘긴다.
			    	System.out.println();
					System.out.println("────────────────────────────");
					System.out.println("  회원정보가 수정되었습니다.");
					System.out.println("────────────────────────────");      // 출력한다.
		    	 
		      } else {
		    	    System.out.println("──────────────────────────────");
					System.out.println(" 회원정보 수정에 실패했습니다.");
					System.out.println("──────────────────────────────");
		      }
				menu();   // 입력받고 출력한 뒤에는 업무방향에 따라서 어디로 어떻게 이동할지 생각한다.
					
		
	} // modify end
	
	public void remove(String mid) {
		System.out.println("┌───────────────────────────────┐");
		System.out.println("│         MEMBER DELETE         │" );
		System.out.println("└───────────────────────────────┘");
		System.out.println();
		
		System.out.print("💡회원 정보를 삭제하시겠습니까? (Y | N) >>> ");  // 의사확인
		String answer = sc.next();
		System.out.println();
		
		  if(answer.equalsIgnoreCase("Y")) {  // equalsIgnoreCase는 대소문자 구분없이 사용할 수 있다.
			 
			  if(mdao.delete(mid)){	
				    System.out.println(" ────────────────────────");
			  		System.out.println("  삭제가 완료되었습니다. "); 									// 반환되는 값을 받아서  // dao에 넘긴다.
			        System.out.println("   메인으로 이동합니다.  ");
			        System.out.println(" ────────────────────────");
			        
			 	}else {
				 System.out.println("삭제에 실패했습니다.");
			 	}
	  		}else if(answer.equalsIgnoreCase("N")) {
	    	  	System.out.println("삭제가 취소되었습니다.");
	  		}else {
    	        System.out.println("Y나 N을 선택해주세요.");
       }		  
				menu();
		
	} // remove end
	
}  // class end
