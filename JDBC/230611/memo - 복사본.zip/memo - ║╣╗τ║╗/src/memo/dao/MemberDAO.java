package memo.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import memo.util.DBConn;
import memo.vo.MemberVO;

public class MemberDAO {
	private String query;
	private PreparedStatement psmt;
	private ResultSet rs;
	private MemberVO mvo;

	public boolean insert(MemberVO mvo) {
		try { // 쿼리를 실행하다가 예외가 발생할 수 있으니까 try/ catch문에다가 // insert 쿼리문
			query = " INSERT INTO t_member VALUES (?,?,?,?,SYSDATE)";

			// 매개변수로 넘겨받은 데이터를 t_member 테이블에 저장
			psmt = DBConn.getConnection().prepareStatement(query);

			psmt.setString(1, mvo.getMid());
			psmt.setString(2, mvo.getMname());
			psmt.setInt(3, mvo.getMage());
			psmt.setString(4, mvo.getMphone());

			int result = psmt.executeUpdate();

			if (result == 1) { // 정상적으로 회원가입 성공 시 true 반환
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(psmt);
		}

		// 그렇지 않으면 false 반환
		return false;

	} // insert end

	public boolean login(String mid, String mphone) {

		try {
			query = "SELECT COUNT (*) FROM T_MEMBER WHERE MID = ? AND MPHONE=?";// 로그인 하는 쿼리 작성
			psmt = DBConn.getConnection().prepareStatement(query);

			psmt.setString(1, mid);
			psmt.setString(2, mphone);

			rs = psmt.executeQuery(); // 매개변수로 넘겨받은 유효한 사용자인지 확인

			if (rs.next()) { // 조회된 레코드가 있다면
				if (rs.getInt(1) == 1) { // COUNT로 사용했으니 1이 넘겨오면 사용자가 있다. -> 로그인 가능
					return true; // COUNT 로 0 이 넘어오면 사용자 존재 안함 -> 로그인 불가 메시지
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}
		return false;
	} // login end

	// 해당레코드 모두 가지고 있는 memberVO
// 나의 정보 조회 - 매개변수로 아이디를 넘겨받아 해당레코드를 객체에 저장하여 반환하는 select() 메서드 ( 접근제한 x)
	public MemberVO select(String id) { // mid를 받아온다. 메인에서 select(mid로 값을 받아옴)
			MemberVO mvo = null;
		try {
			query = "SELECT * FROM t_member WHERE MID=?"; // 쿼리문 아이디 조회하는
			psmt = DBConn.getConnection().prepareStatement(query);// 실행할 prepared

			psmt.setString(1, id); // 물음표 바인딩 // 여기서 넘어온 mid

			rs = psmt.executeQuery(); // 실행한다. executeQuery 는 resultSet 으로 온다. 그래서 int로 받을 수 없다. 결과가 있기 때문에

			if (rs.next()) { // 조회된 레코드가 있다면 // == true 기본
				mvo = new MemberVO(); // MemberVO 객체를 생성하여
				mvo.setMid(rs.getString("mid")); // 해당 레코드 값을 저장
				mvo.setMname(rs.getString("mname"));
				mvo.setMage(rs.getInt("mage"));
				mvo.setMphone(rs.getString("mphone"));
				mvo.setMdate(rs.getDate("reg_date"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(rs, psmt);

		}
		return mvo;
	} // select end
	
	public boolean update(MemberVO mvo) {
		 try {  
			   query = " UPDATE t_member SET MNAME=?, MPHONE=? WHERE MID=?";
			   
			   psmt = DBConn.getConnection().prepareStatement(query);
			
			   psmt.setString(1, mvo.getMname());   // 쿼리 ? 개수만큼 값을 입력
			   psmt.setString(2, mvo.getMphone());
			   psmt.setString(3,mvo.getMid());
			  
			   int result = psmt.executeUpdate();
			 
			   if(result ==1) {   // 정상적으로 회원수정 성공 시 true 반환
				  return true; }
		  		} catch (SQLException e) {
		  			e.printStackTrace();
		  		}finally {   
		  		 DBConn.close(psmt);
		  		}
		  		// 그렇지 않으면  false 반환
		      return false;
	} // update end
	
	public boolean delete(String id) { 
		  try {
		  query = "DELETE t_member WHERE MID = ? ";
		  
		  psmt = DBConn.getConnection().prepareStatement(query);
		  psmt.setString(1,id);
		  
		  	int result = psmt.executeUpdate();
		  	
		  	 if(result ==1) {  
		  		 return true;        // 정상적으로 회원가입 성공 시 true 반환
				   }
		  		} catch (SQLException e) {
		  			e.printStackTrace();
		  		}finally {   
		  		 DBConn.close(psmt);
		  		}
		  		// 그렇지 않으면  false 반환
		  		return false ;	   
			    
		  } // delete end
	
	public List<MemberVO> select(){
		List<MemberVO>mvoList = new ArrayList<MemberVO>();
		
		MemberVO mvo = null;
		
		try {
			query = "SELECT * FROM t_member";
			psmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			
			rs = psmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
			mvo = new MemberVO();   //  MemberVO 객체를 생성하여 
			mvo.setMid(rs.getString("mid"));						//  해당 레코드 값을 저장
			mvo.setMname(rs.getString("mname"));
			mvo.setMage(rs.getInt("mage"));
			mvo.setMphone(rs.getString("mphone"));
			mvo.setMdate(rs.getDate("reg_date"));	
		
			mvoList.add(mvo);	// list 객체에 추가
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, psmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return mvoList;
		
		
	}  // select list end
	
	
	
	
	
	
	

} // class end