package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.SalaryInfoVO;

public class SalaryInfoDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean salInsert(SalaryInfoVO sid) {
	return false;
      
   }
   
   public List<SalaryInfoVO> salSelect(SalaryInfoVO sid) {
	return null;
      
   }
   
   public SalaryInfoVO salSelect(String sid) {
	return null;
      
   }
   public boolean salUpdate(SalaryInfoVO sid) {
	return false;
      
   }
   
   public boolean salDelete(String sid) {
	return false;
      
   }
   
}