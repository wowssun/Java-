package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import hr.util.DBConn;
import hr.vo.HRSystemVO;

public class HRSystemDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   private HRSystemVO hrsysVO;
   
   
   public boolean loginCheck(String id, String pw) {    // 로그인을 하자. 매개변수로 String id, pw 를 받는다. 여기에 써있는 매개변수는 그냥 이름, 저장되어있는
	   try {											// 어떠한 String 값을 id와 pw 이름을 지정한 것. 그 대신 앞의 값이 id, 뒤에 값이 pw 겠지?
			query = "SELECT COUNT (*) FROM HR_SYSTEM WHERE ID = ? AND PW = ?";			// 로그인 하는 쿼리 작성 select count한다. select count는 null값도 가져온다.
																						// where 조건은! id값과 pw로
			pstmt = DBConn.getConnection().prepareStatement(query);						// DBConn 클래스의  getConnection() 메서드를 호출 -> 데이터 베이스 연결
																						// prepareStatement() 메서드를 사용하여 SQL 쿼리를 실행할 PreparedStatement 객체를 생성
			pstmt.setString(1, id);   // 가져온 id값을 첫번째 물음표로
			pstmt.setString(2, pw);	  // 가져온 pw값을 두번째 물음표로  그럼 쿼리가 완성된다!!!!!!

			rs = pstmt.executeQuery(); // 매개변수로 넘겨받은 유효한 사용자인지 확인

			if (rs.next()) { // 조회된 레코드가 있다면
				if (rs.getInt(1) == 1) { // COUNT로 사용했으니 1이 넘겨오면 사용자가 있다. -> 로그인 가능
					return true; // COUNT 로 0 이 넘어오면 사용자 존재 안함 -> 로그인 불가 메시지
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}
	    return false;
	   
   } // loginCheck end
   
   
   // 비밀번호 변경, 초기화
   public boolean pwUpdate(HRSystemVO hrsysVO) {
	   try {  
		   query = " UPDATE HR_SYSTEM SET PW =? WHERE ID = ?";
		   
		   pstmt = DBConn.getConnection().prepareStatement(query);
		
		   pstmt.setString(1, hrsysVO.getPw());   // 쿼리 ? 개수만큼 값을 입력
		   pstmt.setString(2, hrsysVO.getId());
		   
		  
		   int result = pstmt.executeUpdate();
		 
		   if(result ==1) {   // 정상적으로 비밀번호 변경시 true 반환
			  return true; }
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		}finally {   
	  		 DBConn.close(pstmt);
	  		}   
	   		return false;
      
   } // update end
   
   
   
   
}