package hr.main;

import java.util.Scanner;

import hr.dao.HRSystemDAO;
import hr.util.DBConn;
import hr.vo.HRSystemVO;

public class HRSystemMain {

	private Scanner sc;
	private HRSystemDAO hrsdao;
	private HRSystemVO hrsysVO;
	public static String sysid;   // 로그인하는 아이디를 공유변수로 저장
	
	
	public HRSystemMain() {
		sc = new Scanner(System.in);
		hrsdao = new HRSystemDAO();	
	}
	
	// 메인 메뉴 여기서 시스템이 시작된다!!
	public static void main(String [] argus) {
		HRSystemMain hrsys = new HRSystemMain();
		hrsys.dragonInfo();
		hrsys.dragonMain();
	}
	
	// 시스템 시작시 나오는 회사 정보, 인사 ( 추가할 내용 더 찾아보기)
	public void dragonInfo() {
		System.out.println("______  _____  _   _ ______  _      _____  ______ ______   ___   _____  _____  _   _ ");
		System.out.println("|  _  \\|  _  || | | || ___ \\| |    |  ___| |  _  \\| ___ \\ / _ \\ |  __ \\|  _  || \\ | |");
		System.out.println("| | | || | | || | | || |_/ /| |    | |__   | | | || |_/ // /_\\ \\| |  \\/| | | ||  \\| |");
		System.out.println("| | | || | | || | | || ___ \\| |    |  __|  | | | ||    / |  _  || | __ | | | || . ` |");
		System.out.println("| |/ / \\ \\_/ /| |_| || |_/ /| |____| |___  | |/ / | |\\ \\ | | | || |_\\ \\\\ \\_/ /| |\\  |");
		System.out.println("|___/   \\___/  \\___/ \\____/ \\_____/\\____/  |___/  \\_| \\_|\\_| |_/ \\____/ \\___/ \\_| \\_/");
		System.out.println();
		System.out.println("                안녕하세요! 더블 드래곤 인사 관리 시스템에 오신 것을 진심으로 환영합니다. ");
		System.out.println("저희 시스템은 조직의 인사 관리를 보다 효율적이고 원활하게 도와드리기 위해 설계되었습니다.");				
		System.out.println("                     이곳에서는 어쩌구 저쩌구 관리가 가능합니다.  ");
		System.out.println(" 어떠한 도움이 필요하시다면 언제든지 문의해주세요. 즐거운 사용되시길 바랍니다!");					 
		System.out.println();
		
	}
	
	// 메인 메뉴
	public void dragonMain() {
		
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            Main           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    1. 로그인     2. 시스템 종료   ");
		System.out.println();
		System.out.print("    💡 선택(숫자 입력) >>    ");
		int input = sc.nextInt();								// 1번과 2번을 선택받아서 input에 저장
	   	System.out.println();
	   	
	   	switch(input) {											// switch문을 사용하여 
	   		case 1 : login();   								// 1번을 입력받으면 login()메서드로 이동(호출)
	   			break;											// switch문에서 break; 잊지말기
	   		case 2 : sysEnd();									// 2번을 입력받으면 sysEnd() 메서드로 이동(호출)
	   			break;
	   		default : 	System.out.println("--------------------------------");  // if의 else와 같은 기능
		   				System.out.println("    1번이나 2번을 선택하세요.   ");  // 1과 2번 외의 입력을 받을시에
		   				System.out.println("--------------------------------");
		   				dragonMain();											// dragonMain() 호출
		   				System.out.println();
	   	}
	}
	
	// 로그인
	public void login() {
		System.out.println("  ╔═══════════════════════════╗");  
		System.out.println("  ║           LOGIN           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		
		System.out.print("    💡 아이디 >>  ");  
		String id = sc.next();  								// 아이디를 입력받아서 id에 초기화
		System.out.println();
		System.out.print("    💡 비밀번호 >>  ");
		String pw = sc.next();									// 비밀번호를 입력받아서 pw에 초기화
		System.out.println();
		
		HRSystemVO hrsysVO = new HRSystemVO();     				// HrSystemVO 객체(인스턴스) 생성
		hrsysVO.setId(id);										// hrsysVO의 setId에 입력받은 id 를 담아서 보낸다. (인스턴스의 id 필드에 id 값을 설정)
		hrsysVO.setPw(pw);										// hrsysVO의 setPw에 입력받은 pw 를 담아서 보낸다. (인스턴스의 pw 필드에 pw 값을 설정)
		
		if(hrsdao.loginCheck(id, pw)) {   						// HRSystemDAO에 있는 loginCheck()메서드에 id와 pw를 매개변수로 담아 호출, == true 생략
			   System.out.println("-----------------------------");
	    	   System.out.println("     로그인에 성공했습니다   "); 
	    	   System.out.println("-----------------------------");
	    	   System.out.println();
	    	   
	    	   if(id.equals("admin")) {						    // 3개의 계정이 아이디로만 구별되기 때문에 로그인이 성공하고 id가 admin이면 ( 대소문자 구분함)
	    		   System.out.println("-----------------------------------");
	    		   System.out.println(" 인사팀 관리자 계정으로 접속합니다."); 
	    		   System.out.println("-----------------------------------");
	    		   System.out.println();
	    		   sysid = id;									// 그리고 이 계정의 id 값을 공유변수로 선언한 sysid에 저장
	    		  new HrAdminMain().pmMenu();					// 그 후에 HrAdminMain()클래스의 pmMenu()호출 (이동)
	    		  
	    	   }
	    	   else if(id.equals("admin2")) {					// id가 admin2면
	    		   System.out.println("-----------------------------------");
	    		   System.out.println(" 인사팀 열람자 계정으로 접속합니다.");
	    		   System.out.println("-----------------------------------");
	    		   System.out.println();
	    		   sysid = id;
	    		   new HrReadMain().pmReader();
	    	   }
	    	   else if(id.equals("admin3")) {					// id가 admin3이면
	    		   System.out.println("-----------------------------------");
	    		   System.out.println(" 경리팀 열람자 계정으로 접속합니다.");
	    		   System.out.println("-----------------------------------");
	    		   System.out.println();
	    		   sysid = id;
	    		   new AccountAdminMain().adManage();
	    	   }
		} else {																		// HRSystemDAO에서 리턴한 값이 false일떄
			System.out.println("------------------------------------------------");
			System.out.println("   로그인에 실패했습니다. 메인으로 돌아갑니다.  ");	   
			System.out.println("------------------------------------------------");   
			System.out.println();
			dragonMain();																// 메인으로 돌아간다.
		}
		
		System.out.println("-----------------------------------------");
	   	System.out.println("   잘못된 입력입니다. 다시 입력해주세요  ");
	   	System.out.println("-----------------------------------------");
	   	System.out.println();
	   	dragonMain();
		
	   // 인사팀 관리자 HrAdminMain  pmMenu()
	   // 인사팀 열람자 HrReadMain   pmReader()
	   // 경리팀 관리자 AccountAdminMain adManage()
	   //로그인하는 계정이 모두 다르고, 로그인 하는 계정에 따라 다른 메뉴
	   	
	   // 로그인 성공 - > 아이디는 못바꾸니까 아이디로 구별, 아이디 일치하면 해당 권한 메뉴로 이동
	   	
	} //login() end
	
	// 비밀번호 변경
	public void pwChange(HRSystemVO hrsysVO) {  								// HRSystemVO를 매개변수로 받는다. 다음부터는 같은 곳에서 쓰는 vo나 dao 이름 통일하기
		System.out.println("  ╔═══════════════════════════╗");  
		System.out.println("  ║      Change Password      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 변경할 비밀번호 입력 (숫자 4자리) > ");    		
		System.out.println();
	    System.out.print("  💡>> ");
	    hrsysVO.setPw(sc.next());												// 수정된 비밀번호를 입력받고 바로 setPw에 담아 
	    System.out.println();
	    hrsysVO.setId(sysid);													// 공유변수로 만들어 놓은 id도 함꼐
	    
	    if(hrsdao.pwUpdate(hrsysVO)) {											// HRSystemDAO클래스의 pwUdate()메서드에 HRSystemVO를 담아 호출, == true 생략
	    	System.out.println("---------------------------------------");
		    System.out.println("     비밀번호 변경이 완료되었습니다.   ");
		    System.out.println("---------------------------------------");
	    } else {
	    	System.out.println("-------------------------------------------------");
	        System.out.println(" 비밀번호 변경에 실패했습니다. 다시 입력해주세요.");
	    	System.out.println("-------------------------------------------------");
	    }
	    login();																// 비밀번호가 완료, 실패 후에 login()으로 돌아간다.
	    System.out.println();
	} //pwChange end
	
	
	// 비밀번호 초기화
	public void pwReset(HRSystemVO hrsysVO) {									// 비밀번호 변경과 같다.
		System.out.println("  ╔═══════════════════════════╗");  
		System.out.println("  ║       Reset  Password     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 비밀번호를 초기화 하시겠습니까? ( Y | N )");		// 초기화를 묻는 의사를 한번 더입력받고
		System.out.println();
		System.out.print("  💡 >> ");
		String answer = sc.next();
		
		if(answer.equalsIgnoreCase("y")) {											// 만약 대답이 y면 ( 대소문자 구분없음)
			
			switch(sysid) {															// 로그인 한 아이디 값에 따라서, switch문 이용
			case "admin"  : hrsysVO.setId(sysid);  hrsysVO.setPw("1234"); break;	// 원래 지정되어 있었던 아이디값에 따른 비밀번호로 초기화된다.
			case "admin2" : hrsysVO.setId(sysid);  hrsysVO.setPw("5678"); break;	// 그 값을 vo에 setid,와 setpw에 담아 보낸다.
			case "admin3" : hrsysVO.setId(sysid);  hrsysVO.setPw("9998"); break;
			}
			
			if(hrsdao.pwUpdate(hrsysVO)) {
		    	System.out.println("---------------------------------------");
			    System.out.println("    비밀번호 초기화가 완료되었습니다.  ");
			    System.out.println("---------------------------------------");
		    } else {
		    	System.out.println("-------------------------------------");
		        System.out.println("    비밀번호 초기화에 실패했습니다.  ");
		    	System.out.println("-------------------------------------");
		    }
				
		}else if (answer.equalsIgnoreCase("n")) {
			System.out.println("---------------------------------------");
		    System.out.println("    비밀번호 초기화가 취소되었습니다.  ");
		    System.out.println("---------------------------------------");
			
		}else {
			System.out.println("--------------------------------");
			System.out.println("  다시 선택해주세요. ( Y | N )  ");
			System.out.println("--------------------------------");
			System.out.println();
		}
			
		
	}	
	
	// 시스템 종료
	public void sysEnd() {
		System.out.println("  ╔═══════════════════════════╗");  
		System.out.println("  ║        SYSTEM EXIT        ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 시스템을 종료하시겠습니까? ( Y | N )");   
		System.out.println();
		System.out.print("  💡 >> ");
		String input = sc.next();   						// y와 n을 입력받는다.
		System.out.println();
			
		if(input.equalsIgnoreCase("y")) {					// 사용자의 의사가 y일때 ( 대소문자 구분없음)
				System.out.println("--------------------------------");
				System.out.println("     시스템이 종료되었습니다.   ");
				System.out.println("--------------------------------");
				sc.close();		 	// Scanner close.
				DBConn.close();		// connection close. 시스템이 끝나면 끝나지만 명시적으로 하기 위해
				System.exit(0);  // 정상종료
			
		}
		else if (input.equalsIgnoreCase("n")) {  			// 사용자의 의사가 n일때 ( 대소문자 구분없음)
				System.out.println("----------------------------");
				System.out.println("     메인으로 돌아갑니다.   ");
				System.out.println("----------------------------");
				System.out.println();
				dragonMain();								// 메인으로 돌아간다.
		}
		else {												// y, n외에 입력받을 때
			System.out.println("--------------------------------");
			System.out.println("  다시 선택해주세요. ( Y | N )  ");
			System.out.println("--------------------------------");
			System.out.println();
			sysEnd();										// 다시 sysEnd()로
		}
	}
	
		
}
