package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.WorkVO;

public class WorkDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean workInsert(WorkVO wid) {
		return false;
		
	}
	
	public List<WorkVO> WorkSelect() {
		return null;
		
	}
	
	public WorkVO WorkSelect(String wid) {
		return null;
		
	}
	
	public boolean WorkUpdate(WorkVO wid) {
		return false;
		
	}
	public boolean WorkDelete(String wid) {
		return false;
		
	}
	
	
}
