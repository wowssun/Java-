package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.SalaryPaymentVO;

public class SalaryPaymentDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   public boolean salPayInsert(SalaryPaymentVO mid) {
	return false;
   
   }
   
   public List<SalaryPaymentVO> salPaySelect() {
	return null;
      
   }
   
   
   public List<SalaryPaymentVO> salPaySelect(String mid) {
	return null;
      
   }
   
   public SalaryPaymentVO salPaySelect(int mno) {
	return null;
	   
   }
   
   public boolean salPayUpdate(SalaryPaymentVO spid) {
	return false;
      
   }
   
   public boolean salDelete(String mid) {
	return false;
      
   }
      
}