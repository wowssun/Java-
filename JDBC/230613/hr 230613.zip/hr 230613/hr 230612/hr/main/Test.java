package hr.main;

public class Test {

	public static void main(String[] args) {
		   int  a = 1;
		   String  b = "D1001";
		   int  c = 20;
		   int  d = 15;
		   int  e = 10;
		   int  f = 11;
		   int  g = 13;
		   int  h = 69;
		   String j = "D";
		   String bigo = "임금 15% 보너스";
		   String k = "23-06-12";
		   String q = "D1";
		   String r = "부장";
	       
	       
		   
		   	System.out.println("───────────────────────────────────────────────────────");
			System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 | 평가일시 ");
			System.out.println("───────────────────────────────────────────────────────");
			System.out.println("  1 |   D1001  |    D1    | 부장 |     D    | 23-06-12 ");
			System.out.println("───────────────────────────────────────────────────────");
		    System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s",a,b,q,r,j,k);
		   
		   
		   
	        
//	        System.out.println("───────────────────────────────────────────────");
//	        System.out.println(" 아이디 | 이름 | 나이 |   전화번호  | 가입일자 ");
//	        System.out.println("───────────────────────────────────────────────");
//	        System.out.println("aaa     |ayo   |20    |010-7878-7878|2023-05-24");
//	        System.out.printf("%8s|%6s|%6d|%13s|%10s%n",mid,name,age,phone,date);
//	        System.out.println("bbb|bbb|11|010-2222-2222|2023-05-24");
//	        System.out.println("ccc|ccc|12|010-3333-3333|2023-05-24");
//	        System.out.println("ddd|ddd|13|010-4444-4444|2023-05-24");
//	        System.out.println("eee|eee|14|010-5555-5555|2023-05-24");
//	        System.out.println("admin|admin|100|1111|2023-05-27");

	}

}
