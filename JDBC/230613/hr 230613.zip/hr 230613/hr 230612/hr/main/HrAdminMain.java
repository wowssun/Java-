package hr.main;

import java.util.Scanner;

import hr.dao.EmployeeDAO;
import hr.dao.HistoryDAO;
import hr.dao.ReviewDAO;
import hr.dao.SalaryInfoDAO;
import hr.dao.SalaryPaymentDAO;
import hr.dao.WorkDAO;
import hr.dao.YearDAO;
import hr.vo.HRSystemVO;
import hr.vo.ReviewVO;

public class HrAdminMain {
	
	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryInfoDAO sdao;
	private SalaryPaymentDAO spdao;
	private HRSystemVO hrsysVO;
	private ReviewVO revo;
	private ReviewDAO reda;
	private HrReadMain hrrma;
	
	public  HrAdminMain() {
		sc = new Scanner(System.in);
		hrsysVO = new HRSystemVO();
		revo = new ReviewVO();
		reda = new ReviewDAO();
	
	}
	
	public static void main(String [] args) {
	 new HrAdminMain().pmMenu();
	}
	
	public void pmMenu() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            MENU           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 관리       2. 근태 관리      ");
		System.out.println("  3. 급여 조회       4. 인사고과 관리  ");
		System.out.println("  5. 비밀번호 변경   6. 시스템 종료    ");
		System.out.println("  7. 비밀번호 초기화");
	    System.out.println();
	    System.out.print("  💡 선택(숫자 입력) >> ");
	    int num = sc.nextInt();
	    System.out.println();
	   	
	   	switch(num) {
	   		case 1 : emManage();
	   			break;
	   		case 2 : workManage();
	   			break;
	   		case 3 : new HrReadMain().salMain();
	   			break;
	   		case 4 : revManage();
	   			break;
	   		case 5 : new HRSystemMain().pwChange(hrsysVO);
	   			break;
	   		case 6 : new HRSystemMain().sysEnd(); break;
	   		case 7 : new HRSystemMain().pwReset(hrsysVO);
	   		default : 
	   			System.out.println("--------------------------------");
	   		   	System.out.println("    1번 ~ 6번을 선택해주세요.   ");
	   		   	System.out.println("--------------------------------");
	   		   	System.out.println();
	   		    pmMenu();
	   	    
	   	}
	}
	
	
	public void emManage() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        직원 관리 메뉴     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 정보 등록  2. 직원 전체 목록");
		System.out.println("  3. 히스토리 등록   4. 히스토리 목록");
		System.out.println("  5. 메인 메뉴 ");
		System.out.println();
		System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("    1번 ~ 5번을 선택해주세요.     ");
	   	System.out.println("--------------------------------");
		
	}
	
	public void emWrite() {
		System.out.println("  ╔═══════════════════════════════════╗");  // 2칸씩
		System.out.println("  ║            직원 정보 등록         ║");
		System.out.println("  ╠═══════════════════════════════════║");
		System.out.println("  ║(예시)                             ║");
		System.out.println("  ║생년월일 >> YY.MM.DD               ║");
		System.out.println("  ║연락처　>> 010-0000-0000           ║");
		System.out.println("  ║성별 >> 여성 | 남성                ║");
		System.out.println("  ║입사일자 >> YY.MM.DD               ║");
		System.out.println("  ║직급 >> 사원 | 대리 | 과장 | 부장  ║");
		System.out.println("  ╚═══════════════════════════════════╝");
		System.out.println();
		System.out.println("  < 등록할 직원의 정보를 입력해주세요> ");
		System.out.println();
		System.out.println("   1. 직원번호 >> ");
		System.out.println("   2. 직원이름 >> ");
		System.out.println("   3. 생년월일 >> ");
		System.out.println("   4. 연락처 >> ");
		System.out.println("   5. 성별 >> ");
		System.out.println("   6. 주소 >> ");
		System.out.println("   7. 입사일자 >> ");
		System.out.println("   8. 부서 번호 >> ");
		System.out.println("   9. 직급 >> ");
		System.out.println("  10. 호봉 >> ");
		System.out.println();
		System.out.println("----------------------------------");
		System.out.println("  입력하신 정보가 저장되었습니다. ");
		System.out.println("----------------------------------");
		System.out.println("----------------------------------");
		System.out.println("     직원관리 메뉴로 돌아갑니다.  ");
	   	System.out.println("----------------------------------");
	   	System.out.println("----------------------------------");
	   	System.out.println("      정보 등록에 실패했습니다.  " );
	   	System.out.println("----------------------------------");
		
		
	}
	
	public void emModify(String emid) {
		System.out.println("  ╔═══════════════════════════════════╗");  // 2칸씩
		System.out.println("  ║         직원 정보 수정            ║");
		System.out.println("  ╠═══════════════════════════════════║");
		System.out.println("  ║(예시)                             ║");
		System.out.println("  ║생년월일 >> YY.MM.DD               ║");
		System.out.println("  ║연락처　>> 010-0000-0000           ║");
		System.out.println("  ║성별 >> 여성 | 남성                ║");
		System.out.println("  ║입사일자 >> YY.MM.DD               ║");
		System.out.println("  ║직급 >> 사원 | 대리 | 과장 | 부장  ║");
		System.out.println("  ╚═══════════════════════════════════╝");
		System.out.println();
		System.out.println("        < 정보를 수정하세요.>");
		System.out.println();
		System.out.println("   1. 직원번호 >> ");
		System.out.println("   2. 직원이름 >> ");
		System.out.println("   3. 생년월일 >> ");
		System.out.println("   4. 연락처 >> ");
		System.out.println("   5. 성별 >> ");
		System.out.println("   6. 주소 >> ");
		System.out.println("   7. 입사일자 >> ");
		System.out.println("   8. 부서 번호 >> ");
		System.out.println("   9. 직급 >> ");
		System.out.println("  10. 호봉 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("        정보가 수정되었습니다.       ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("     직원관리 메뉴로 돌아갑니다.      ");
	   	System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         수정에 실패했습니다.       ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	public void emRemove(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       직원 정보 삭제      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("------------------------------");
		System.out.println("        삭제되었습니다.        ");  //자동연결 메뉴불러오기
		System.out.println("------------------------------");
		System.out.println("------------------------------");
		System.out.println("        취소되었습니다.      "); //자동연결 메뉴불러오기
		System.out.println("------------------------------");
		System.out.println();
		
	}
	
	public void historyWrite() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       히스토리 등록       ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 번호 >>");
		System.out.println("  2. 현재 부서 >> ");
		System.out.println("  3. 부서 등록 날짜 >> ");
		System.out.println("  4. 부서 이동 날짜 >> ");
		System.out.println("  5. 현재 직급 >> ");
		System.out.println("  6. 승진 날짜 >> ");
		System.out.println("  7. 휴직 시작 날짜 >> ");
		System.out.println("  8. 휴직 종료 날짜 >> ");
		System.out.println("  9. 비고 >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("        등록이 완료되었습니다.       ");
	   	System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("         등록에 실패했습니다.       ");
	 	System.out.println("--------------------------------");
		
	}
	
	public void historyModify(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        히스토리 수정      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("      수정할 내용을 입력해주세요  ");
		System.out.println();
		System.out.println("  1. 현재 부서 >> ");
		System.out.println("  2. 부서 등록 날짜 >> ");
		System.out.println("  3. 부서 이동 날짜 >> ");
		System.out.println("  4. 현재 직급 >> ");
		System.out.println("  5. 승진 날짜 >> ");
		System.out.println("  6. 휴직 시작 날짜 >> ");
		System.out.println("  7. 휴직 종료 날짜 >> ");
		System.out.println("  8. 비고 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("     히스토리가 수정되었습니다.     ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("       수정에 실패했습니다.       ");
	   	System.out.println("--------------------------------");
		
	}
	
	public void historyRemove(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        히스토리 삭제      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("------------------------------------");
		System.out.println("  삭제되었습니다. 직원관리 메뉴로 돌아갑니다.");  //자동연결 메뉴불러오기
		System.out.println("------------------------------------");
		System.out.println("------------------------------------");
		System.out.println("  취소되었습니다. 직원관리 메뉴로 돌아갑니다."); //자동연결 메뉴불러오기
		System.out.println("------------------------------------");
		
	}
	
	
	public void workManage() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       근태 관리 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 근태 기록 등록  2. 근태 기록 목록");
		System.out.println("  3. 연차 승인 등록  4. 연차 승인내역 목록 ");
		System.out.println("  5. 메인메뉴");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("       1번 ~ 5번을 선택해주세요.     ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	public void workWrite() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        근태 기록 등록     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  < 근태 기록을 위한 정보를 입력해주세요.>");
		System.out.println();
		System.out.println("  1.직원번호 >>");
		System.out.println("  2.근속년수 >>");
		System.out.println("  3.지각일수 >>");
		System.out.println("  4.조퇴일수 >>");
		System.out.println("  5.결근일수 >>");
		System.out.println("  6.사용가능 연차일수 >>");
		System.out.println("  7.사용연차일수 >>");
		System.out.println("  8.잔여연차일수 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("        등록이 완료되었습니다.      ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("       정보 등록에 실패했습니다.     ");
		System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public void workModify(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       근태 기록 수정      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.근속년수 >>");
		System.out.println("  2.지각일수 >>");
		System.out.println("  3.조퇴일수 >>");
		System.out.println("  4.결근일수 >>");
		System.out.println("  5.사용가능 연차일수 >>");
		System.out.println("  6.사용연차일수 >>");
		System.out.println("  7.잔여연차일수 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("       근태 기록이 수정되었습니다.    ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         수정에 실패했습니다.       ");
	   	System.out.println("--------------------------------");
	
		
	}
	
	public void workRemove(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║        근태 기록 삭제     ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
		System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("           삭제되었습니다.          ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("           취소되었습니다.          ");
	   	System.out.println("--------------------------------");
	}
	
	public void yearWrite() {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       연차 승인 등록      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 등록할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.직원번호 >> ");
		System.out.println("  2.연차사용날짜 >> ");
		System.out.println("  3.연차사용일수 >> ");
		System.out.println("  4.연차승인자 >> ");
		System.out.println("  5.연차승인일자 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("       등록되었습니다.          ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("     정보등록에 실패했습니다.   ");
		System.out.println("--------------------------------");
		System.out.println();
		
	}
	
	public void yearModify(String emid) {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    연차 승인 내역 수정    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 내용을 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1.연차사용날짜 >>");
		System.out.println("  2.연차사용일수 >>");
		System.out.println("  3.연차승인자 >>");
		System.out.println("  4.연차승인일자 >>");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("         수정되었습니다.        ");
		System.out.println("--------------------------------");
		System.out.println("--------------------------------");
		System.out.println("        수정에 실패했습니다.    ");
		System.out.println("--------------------------------");
		System.out.println();
	}
	
	public void yearRemove(String emid) {
    	System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    연차 승인 내역 삭제    ║");
		System.out.println("  ╚═══════════════════════════╝");
    	System.out.println();
    	System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
    	System.out.println();
		System.out.println("  💡 입력 >> ");
		System.out.println();
		System.out.println("--------------------------------");
		System.out.println("         삭제되었습니다.         ");
		System.out.println("--------------------------------");
	   	System.out.println("--------------------------------");
	   	System.out.println("         취소되었습니다.          ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
	}
	
	// 인사고과 관리 메뉴
	public void revManage() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    인사 고과 관리 메뉴    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 평가 등록  2. 평가 기록 목록");
		System.out.println("  3. 메인메뉴"                    );  
		System.out.println();
		System.out.print("  💡 선택(숫자 입력) >> ");
		int input  = sc.nextInt();
		System.out.println();
		
	   	System.out.println();
	   	
	   	switch(input) {
	   		case 1 : revWrite();
	   			break;
	   		case 2 : new HrReadMain().revView();
	   			 break;
	   		case 3 :  pmMenu();
	   			break;
   			default : 
   				System.out.println("--------------------------------");
   				System.out.println("    1번 ~ 3번을 선택해주세요.   ");
   				System.out.println("--------------------------------");
   				revManage();
   				System.out.println();
	   	}
	   	
		
	}
	
	// 인사고과 등록
	public void revWrite() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       인사고과 등록       ║");
		System.out.println("  ╠═══════════════════════════║");
		System.out.println("  ║ 각 항목당 점수 : 0 ~ 20점 ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("      < 점수를 입력해주세요 >  ");
		System.out.println();
		System.out.print("  1. 직원번호 >> ");
		String emplid = sc.next();
		System.out.println();
		System.out.println("  2. 관리능력 : 업무 우선순위 선정 및 위기상황 대처 능력의 정도");
		System.out.print("  💡 >> ");
		int one = sc.nextInt();
		System.out.println();
		System.out.println("  3. 유대관계: 구성원 및 타부서 간의 의사소통과 협업 여부");	
		System.out.print("  💡 >> ");
		int two = sc.nextInt();
		System.out.println();
		System.out.println("  4. 책임감 : 담당 일을 책임감 있게 수행하고 그 결과에 대하여 책임을 지는 태도");
		System.out.print("  💡 >> ");
		int three = sc.nextInt();
		System.out.println();
		System.out.println("  5. 근면성 : 성실 근면한 자세로 업무에 임하고 있는지의 여부 (지각,조퇴,결근 반영)");
		System.out.print("  💡 >> ");
		int four = sc.nextInt();
		System.out.println();
		System.out.println("  6. 업무지식 : 담당업무 수행에 필요한 전문지식의 정도");
		System.out.print("  💡 >> ");
		int five = sc.nextInt();
		System.out.println();
		System.out.println("  7. 평가 일시 (yyyy-mm-dd)");
		System.out.print("  💡 >> ");
		String evalDate = sc.next();
		
		int total = one + two + three + four + five;
		
		String grade;
		String remark;
		
		switch (total/10) {
			case 10 : case 9 :  grade = "A"; break;	
			case 8: 			grade = "B"; break;
			case 7:				grade = "C"; break;
			default :           grade = "D";							
		}
		
//		 비고(A: 임금 30% 보너스/B: 임금 15% 보너스/C: 임금 5% 보너스/D: 임금유지 )
		switch(grade) {
			case "A" : remark = "임금 30% 보너스"; break;
			case "B" : remark = "임금 15% 보너스"; break;
			case "C" : remark = "임금 5% 보너스";break;
			case "D" : remark = "임금유지";break;
			default :  remark = " ";
		
		}
		
			revo.setEmid(emplid);
			revo.setEval1(one);
			revo.setEval2(two);
			revo.setEval3(three);
			revo.setEval4(four);
			revo.setEval5(five);
			revo.setEvalTot(total);
			revo.setGrade(grade);
			revo.setRemark(remark);
			revo.setEvalDate(evalDate);
		
		
			if(reda. revInsert(revo)) {
				System.out.println();
				System.out.println("--------------------------------");
				System.out.println("         등록되었습니다.        ");
				System.out.println("--------------------------------");
				System.out.println();
			}else {
				System.out.println();
				System.out.println("--------------------------------");
				System.out.println("       등록에 실패했습니다.     ");
				System.out.println("--------------------------------");
				System.out.println();
			}
			revManage();
//		} else if (yesno.equalsIgnoreCase("n")) {
//			System.out.println(" ───────────────────────────────");
//			System.out.println("    메모 작성을 취소하셨습니다. ");
//			System.out.println();
//			System.out.println("   메모 시스템으로 돌아갑니다.  ");
//			System.out.println(" ───────────────────────────────");
			
//		}else {
//			System.out.println("Y나 N을 선택해주세요");
//		}
		
			
	}
	
	// 인사고과 수정
	public void revModify(ReviewVO revo) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       인사 고과 수정      ║");
		System.out.println("  ╠═══════════════════════════║");
		System.out.println("  ║ 각 항목당 점수 : 0 ~ 20점 ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 점수를 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1. 관리능력 : 업무 우선순위 선정 및 위기상황 대처 능력의 정도");
		System.out.print("  💡 >> ");
		int one = sc.nextInt();
		System.out.println();
		System.out.println("  2. 유대관계: 구성원 및 타부서 간의 의사소통과 협업 여부");	
		System.out.print("  💡 >> ");
		int two = sc.nextInt();
		System.out.println();
		System.out.println("  3. 책임감 : 담당 일을 책임감 있게 수행하고 그 결과에 대하여 책임을 지는 태도");
		System.out.print("  💡 >> ");
		int three = sc.nextInt();
		System.out.println();
		System.out.println("  4. 근면성 : 성실 근면한 자세로 업무에 임하고 있는지의 여부 (지각,조퇴,결근 반영)");
		System.out.print("  💡 >> ");
		int four = sc.nextInt();
		System.out.println();
		System.out.println("  5. 업무지식 : 담당업무 수행에 필요한 전문지식의 정도");
		System.out.print("  💡 >> ");
		int five = sc.nextInt();
		
		int total = one + two + three + four + five;
		
		String grade;
		String remark;
		
		switch (total/10) {
			case 10 : case 9 :  grade = "A"; break;	
			case 8: 			grade = "B"; break;
			case 7:				grade = "C"; break;
			default :           grade = "D";							
		}
		
//		 비고(A: 임금 30% 보너스/B: 임금 15% 보너스/C: 임금 5% 보너스/D: 임금유지 )
		switch(grade) {
			case "A" : remark = "임금 30% 보너스"; break;
			case "B" : remark = "임금 15% 보너스"; break;
			case "C" : remark = "임금 5% 보너스"; break;
			case "D" : remark = "임금유지"; break;
			default :  remark = " ";
		
		}
			revo.setEval1(one);
			revo.setEval2(two);
			revo.setEval3(three);
			revo.setEval4(four);
			revo.setEval5(five);
			revo.setEvalTot(total);
			revo.setGrade(grade);
			revo.setRemark(remark);
			
			if(reda.revUpdate(revo)) {
				System.out.println();
				System.out.println("--------------------------------");
				System.out.println("         수정되었습니다.        ");
				System.out.println("--------------------------------");
				System.out.println();
			}else {
				System.out.println("--------------------------------");
				System.out.println("        수정에 실패했습니다.    ");
				System.out.println("--------------------------------");
				System.out.println();
			}
			revManage();
		
	} // revModify end
	
		
	
	// 전체 항목 수정
	public void revModify6(ReviewVO revo) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       인사 고과 수정      ║");
		System.out.println("  ╠═══════════════════════════║");
		System.out.println("  ║ 각 항목당 점수 : 0 ~ 20점 ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("    < 수정할 점수를 입력해주세요 >  ");
		System.out.println();
		System.out.println("  1. 관리능력 : 업무 우선순위 선정 및 위기상황 대처 능력의 정도");
		System.out.print("  💡 >> ");
		int one = sc.nextInt();
		System.out.println();
		System.out.println("  2. 유대관계: 구성원 및 타부서 간의 의사소통과 협업 여부");	
		System.out.print("  💡 >> ");
		int two = sc.nextInt();
		System.out.println();
		System.out.println("  3. 책임감 : 담당 일을 책임감 있게 수행하고 그 결과에 대하여 책임을 지는 태도");
		System.out.print("  💡 >> ");
		int three = sc.nextInt();
		System.out.println();
		System.out.println("  4. 근면성 : 성실 근면한 자세로 업무에 임하고 있는지의 여부 (지각,조퇴,결근 반영)");
		System.out.print("  💡 >> ");
		int four = sc.nextInt();
		System.out.println();
		System.out.println("  5. 업무지식 : 담당업무 수행에 필요한 전문지식의 정도");
		System.out.print("  💡 >> ");
		int five = sc.nextInt();
		
		int total = one + two + three + four + five;
		
		String grade;
		String remark;
		
		switch (total/10) {
			case 10 : case 9 :  grade = "A"; break;	
			case 8: 			grade = "B"; break;
			case 7:				grade = "C"; break;
			default :           grade = "D";							
		}
		
//		 비고(A: 임금 30% 보너스/B: 임금 15% 보너스/C: 임금 5% 보너스/D: 임금유지 )
		switch(grade) {
			case "A" : remark = "임금 30% 보너스"; break;
			case "B" : remark = "임금 15% 보너스"; break;
			case "C" : remark = "임금 5% 보너스"; break;
			case "D" : remark = "임금유지"; break;
			default :  remark = " ";
		
		}
			revo.setEval1(one);
			revo.setEval2(two);
			revo.setEval3(three);
			revo.setEval4(four);
			revo.setEval5(five);
			revo.setEvalTot(total);
			revo.setGrade(grade);
			revo.setRemark(remark);
			
			if(reda.revUpdate(revo)) {
				System.out.println();
				System.out.println("--------------------------------");
				System.out.println("         수정되었습니다.        ");
				System.out.println("--------------------------------");
				System.out.println();
			}else {
				System.out.println("--------------------------------");
				System.out.println("        수정에 실패했습니다.    ");
				System.out.println("--------------------------------");
				System.out.println();
			}
			revManage();
		
	}
	
	
	// 인사고과 삭제
	public void revRemove(int reno) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       인사 고과 삭제      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
    	System.out.println(" < 삭제하려면 Y를 그렇지 않으면 N을 입력해주세요 >");
    	System.out.println();
		System.out.print("  💡 입력 >> ");
		String answer = sc.next();
		System.out.println();
		
		
		
		if(answer.equalsIgnoreCase("Y")) {  // equalsIgnoreCase는 대소문자 구분없이 사용할 수 있다.
			
			  if(reda.revDelete(reno)){	
				  	System.out.println("--------------------------------");
					System.out.println("         삭제되었습니다.        ");
					System.out.println("--------------------------------");
			        
			 	}else {
			 		System.out.println("--------------------------------");
					System.out.println("     삭제를 실패하였습니다.     ");
					System.out.println("--------------------------------");
			 	}
	  		}else if(answer.equalsIgnoreCase("N")) {
	  			System.out.println("--------------------------------");
	  		   	System.out.println("         취소되었습니다.         ");
	  		   	System.out.println("--------------------------------");
	  		}else {
	  			System.out.println("--------------------------------");
				System.out.println("  다시 선택해주세요. ( Y | N )  ");
				System.out.println("--------------------------------");
				System.out.println();
     }
		revManage();
		
	}	
	

}
