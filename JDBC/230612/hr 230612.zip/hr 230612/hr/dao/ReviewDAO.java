package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import hr.util.DBConn;
import hr.vo.ReviewVO;

public class ReviewDAO {

   private String query;
   private PreparedStatement pstmt;
   private ResultSet rs;
   
   // 평가 등록
   public boolean revInsert(ReviewVO revo) {
	   try {  // 쿼리를 실행하다가 예외가 발생할 수 있으니까 try/ catch문에다가 	// insert 쿼리문
		   query = " INSERT INTO REVIEW VALUES (SEQ_REVIEW_REVIEW_NO.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
		   
		  // 매개변수로 넘겨받은 데이터를 t_member 테이블에 저장
		   pstmt = DBConn.getConnection().prepareStatement(query);
		
		   pstmt.setString(1, revo.getEmid());
		   pstmt.setInt(2, revo.getEval1());
		   pstmt.setInt(3, revo.getEval2());
		   pstmt.setInt(4, revo.getEval3());
		   pstmt.setInt(5, revo.getEval4());
		   pstmt.setInt(6, revo.getEval5());
		   pstmt.setInt(7, revo.getEvalTot());
		   pstmt.setString(8, revo.getGrade());
		   pstmt.setString(9, revo.getRemark());
		   pstmt.setString(10, revo.getEvalDate());
		 
		     
		   int result = pstmt.executeUpdate();
		 
		   if(result ==1) {   // 정상적으로 회원가입 성공 시 true 반환
			  return true; }
	  		} catch (SQLException e) {
	  			e.printStackTrace();
	  		}finally {   
	  		 DBConn.close(pstmt);
	  		}
	  		// 그렇지 않으면  false 반환
	  		return false;	  	   	
      
   } // revInsert end
   
   // 평가 전체 목록 
   public List<ReviewVO> revSelect() {
	    List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
  			e.printStackTrace();
  		}finally { 
  		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
  		}	
		return reviewList;
	    	
      
   } // revInsert(ReviewVO revo) end
   
   // 평가 부서별
   public List<ReviewVO> revSelectD(String dno) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND d.dno = ?"
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1, dno);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
 			e.printStackTrace();
 		}finally { 
 		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
 		}	
		return reviewList;
      
   }
   
   // 평가 직급별
   public List<ReviewVO> revSelectP(String position) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND e.position = ?"
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1, position);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
		return reviewList;
     
      
   }
   
   // 평가 연도별
   public List<ReviewVO> revSelectY(String evaldate) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND substr(r.eval_date,1,4) = ?"
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1,evaldate );
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
		return reviewList;
    
      
   }
   
   // 평가 개인조회
   public List<ReviewVO> revSelect(String emid) {
	   List<ReviewVO> reviewList = new ArrayList<ReviewVO>();
	    
	    ReviewVO revo = null;
	    
	    try {
			query =   " SELECT r.review_no, e.emid, d.dno, e.position, r.grade, r.eval_date"
					+ " FROM  review r, employees e, departments d"
					+ " WHERE r.emid = e.emid(+)"
					+ " AND e.dname = d.dname(+)"
					+ " AND e.emid = ?"
					+ " ORDER BY r.review_no ASC";
			
			pstmt = DBConn.getConnection().prepareStatement(query);  // 바인딩이 없으니 이것만 사용
			pstmt.setString(1, emid);
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {   //. 여러 줄이니까 while 
				revo = new ReviewVO();   //  MemberVO 객체를 생성하여 
				revo.setReno(rs.getInt("review_no"));
				revo.setEmid(rs.getString("emid"));
				revo.setDno(rs.getString("dno"));						//  해당 레코드 값을 저장
				revo.setPosition(rs.getString("position"));
				revo.setGrade(rs.getString("grade"));	
				revo.setEvalDate(rs.getString("eval_date"));
			
				reviewList.add(revo);	// list 객체에 추가
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { 
		 DBConn.close(rs, pstmt); // 사용한 코드가 rs와 psmt다. 이 두개를 닫기
		}	
		return reviewList;
	
      
   }
   
   // 평가 상세 조회?
   public ReviewVO revSelect(int rno) {
	return null;
	   
   }
   
   // 평가 수정
   public boolean revUpdate(ReviewVO rid) {
	return false;
      
   }
   
   // 평가 삭제
   public boolean revDelete(String rid) {
	return false;
      
   }
   
}