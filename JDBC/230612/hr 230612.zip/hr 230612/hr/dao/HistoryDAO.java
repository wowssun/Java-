package hr.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import hr.vo.HistoryVO;

public class HistoryDAO {

	private String query;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public boolean hisInsert(HistoryVO mid) {
		return false;
		
	}
	
	public List<HistoryVO> hisSelect() {
		return null;
		
	}
	
	public List<HistoryVO> hisSelect(String mid) {
		return null;
		
	}
	
	public HistoryVO hisSelect(int mno) {
		return null;
		
	}
	
	public boolean hisUpdate(HistoryVO mid) {
		return false;
		
	}
	
	
	public boolean hisDelete(String mid) {
		return false;
		
	}
		
}
