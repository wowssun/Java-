package hr.main;

import java.util.List;
import java.util.Scanner;

import hr.dao.EmployeeDAO;
import hr.dao.HistoryDAO;
import hr.dao.ReviewDAO;
import hr.dao.SalaryInfoDAO;
import hr.dao.SalaryPaymentDAO;
import hr.dao.WorkDAO;
import hr.dao.YearDAO;
import hr.vo.HRSystemVO;
import hr.vo.ReviewVO;

public class HrReadMain {

	private Scanner sc;
	public static String id;
	private EmployeeDAO edao;
	private HistoryDAO hdao;
	private WorkDAO wdao;
	private YearDAO ydao;
	private SalaryInfoDAO sdao;
	private SalaryPaymentDAO spdao;
	private ReviewDAO rdao;
	private HRSystemVO hrsysVO;
	private ReviewVO revo;
	
	public static void main(String [] args) {
		new HrReadMain().pmReader();
	}
	
	public HrReadMain() {
		sc = new Scanner (System.in);
		revo = new ReviewVO();
		rdao = new ReviewDAO();
		hrsysVO = new HRSystemVO();
	}

	public void pmReader() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║            MENU           ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 정보 조회   2. 근태 조회 ");
		System.out.println("  3. 급여 조회        4. 인사고과 조회 ");
		System.out.println("  5. 비밀번호 변경    6. 시스템 종료");
		System.out.println();
	    System.out.print("  💡 선택(숫자 입력) >> ");
	    int input = sc.nextInt();
	    System.out.println();
		
	   	switch(input) {
	   	case 1 : emView();
	   		break;
	   	case 2 : workView();
	   		break;
	   	case 3 : salMain();
	   		break;
	   	case 4 : revView();
	   		break;
	   	case 5 :  new HRSystemMain().pwChange(hrsysVO);
	   		break;
	   	case 6 : new HRSystemMain().sysEnd();
	   		break;
	   	default :
	   		System.out.println("--------------------------------");
	   		System.out.println("     1번 ~ 6번을 선택해주세요.  ");
	   		System.out.println("--------------------------------");
	   		System.out.println();
	   	}  
	   	
	} //  pmReader end
	
	public void emView() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       직원 조회 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 직원 전체 목록  2. 히스토리 목록");
		System.out.println("  3. 메인 메뉴                       ");  
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
		
		
	}
	
	public void emList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       직원 전체 목록      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("────────────────────────────────────────────────────────");
        System.out.println(" NO. |  직원번호 | 직원이름  |  성별 |  부서번호 | 직급 ");
        System.out.println("────────────────────────────────────────────────────────");
        System.out.println("  1  |           |           |      |            |      ");
        System.out.println("────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println(" 1. 부서별 조회  2. 직급별 조회");
		System.out.println(" 3. 개별 조회    4. 직원조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
		
	    
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     부서별 직원 조회      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 생산팀(D1)     2. 인사팀(D2)");
		System.out.println("  3. 품질관리팀(D3) 4. 경리팀(D4) ");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("─────────────────────────────────────────────────────");
        System.out.println(" NO. |직원번호 |  직원이름 |  성별 |  부서번호 | 직급 ");
        System.out.println("─────────────────────────────────────────────────────");
        System.out.println("  1  |        |           |       |           |       ");
        System.out.println("─────────────────────────────────────────────────────");
		System.out.println();
        System.out.println();
        System.out.println("  1. 개별 조회  2. 직원 조회 메뉴"); 
        System.out.println();
        System.out.println("  💡 선택(숫자 입력) >> ");
        System.out.println();
        

		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║      직급별 직원 조회　　 ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 사원   2. 대리");
		System.out.println("  3. 과장   4. 부장");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("────────────────────────────────────────────────────────");
        System.out.println(" NO. |직원번호 | 직원이름  |  성별 |  부서번호  | 직급 ");
        System.out.println("────────────────────────────────────────────────────────");
        System.out.println("  1  |         |            |       |           |      ");
        System.out.println("────────────────────────────────────────────────────────");
		System.out.println();
        System.out.println();
        System.out.println("  1. 개별 조회  2. 직원 조회 메뉴"); 
        System.out.println();
        System.out.println("  💡 선택(숫자 입력) >> ");
        System.out.println();
		
		
		
		
	}
	
	public void emDetail(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║      직원 개별 조회       ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 직원번호를 입력하세요 >>  ");
		System.out.println();
		System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println("  NO. |직원번호 | 직원이름 | 성별 | 생년월일 | 연락처 | 입사일자 | 부서번호 | 직급  | 주소");
        System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println("  1  |          |          |      |          |         |          |         |       |      ");
        System.out.println("─────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println();
		System.out.println("  1. 정보 수정  2. 정보 삭제  3. 직원 조회 메뉴");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		
		
	}
	
	public void hisAllList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     히스토리 전체 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("─────────────────────────────────────────────────");
        System.out.println(" NO.| 직원번호 | 직원이름 | 부서코드 |   구분    ");
        System.out.println("─────────────────────────────────────────────────");
        System.out.println("  1 |         |           |          |           ");
        System.out.println("─────────────────────────────────────────────────");
        System.out.println("  2 |         |           |          |            ");
        System.out.println("─────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("  1. 개별 조회  2. 직원조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
		
	}
	
	public void hisList(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     히스토리 개별 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 직원번호를 입력하세요 >>  ");
		System.out.println();
		System.out.println("────────────────────────────────────────────────────────────────────────");
        System.out.println(" NO.| 직원번호 | 직원이름 | 부서코드 | 시작 날짜  |  종료 날짜  | 구분    ");
        System.out.println("─────────────────────────────────────────────────────────────────────────");
        System.out.println("  1 |         |           |          |            |             |          ");
        System.out.println("─────────────────────────────────────────────────────────────────────────");
        System.out.println("  2 |         |           |          |            |             |          ");
        System.out.println("─────────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println("  💡 조회할 번호 선택(숫자 입력) >> ");
		System.out.println();
	   
		
	}
	
	public void hisDetail() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     히스토리 상세 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("────────────────────────────────────────────────────────────────────────");
        System.out.println(" NO.| 직원번호 | 직원이름 | 부서코드 | 시작 날짜  |  종료 날짜  | 구분   ");
        System.out.println("─────────────────────────────────────────────────────────────────────────");
        System.out.println("  1 |         |           |          |            |             |         ");
        System.out.println("─────────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println("  1. 정보 수정  2. 정보 삭제  3. 직원 조회 메뉴");
		System.out.println();

		
	}
	
	public void workView() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       근태 조회 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 근태 기록 목록  ");
	    System.out.println("  2. 연차 승인 내역 목록");
		System.out.println("  3. 메인 메뉴                        ");  
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	
		
	}
	
	public void workList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     근태기록 전체 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("──────────────────────────────────────────────────────────────────────");
        System.out.println(" NO.|직원번호 | 직원이름 | 지각일수 |  조퇴일수 | 결근일수 | 잔여연차일수  ");
        System.out.println("──────────────────────────────────────────────────────────────────────");
        System.out.println(" 1  |         |           |          |           |          |              ");
        System.out.println("──────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("  1. 개별 조회  2. 근태조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
		
	    
	}
	
	public void workDetail(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    근태 기록 개별 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 직원번호를 입력하세요 >>  ");
		System.out.println();
		System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println(" 직원번호 | 직원이름 | 지각일수 |  조퇴일수 | 결근일수 | 사용가능연차일수 | 사용연차이수 | 잔여연차일수                ");
    	System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
        System.out.println("          |          |          |           |          |                  |              |               ");
    	System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────");
    	System.out.println();
    	System.out.println("  1. 근태 기록 수정  2. 근태 기록 삭제  3. 근태 조회 메뉴");
		System.out.println();
		 System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
	}
	
	public void yearAllList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    연차 승인 내역 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("─────────────────────────────────────────────────────");
		System.out.println(" NO. |직원번호 | 직원이름 |  연차승인자 | 연차승인일자");
		System.out.println("─────────────────────────────────────────────────────");
		System.out.println("  1  |        |          |             |             ");
		System.out.println("─────────────────────────────────────────────────────");
		System.out.println("  2  |        |          |             |             ");
		System.out.println("─────────────────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("  1. 개별 조회  2. 근태 조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
	
	    
		
	}
	
	public void yearList(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    연차 승인 내역 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 직원번호를 입력하세요 >>  ");
		System.out.println();
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println(" NO  | 직원번호 | 직원이름 | 연차사용날짜 | 연차사용일수 | 연차승인자 | 연차승인일자");
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println("  1  |        |          |              |              |            |             ");
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println("  2  |        |          |              |              |            |             ");
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println("  💡 조회할 번호 선택(숫자 입력) >> ");
		System.out.println();


	}
	
	public void yearDetail() {
		System.out.println("  ╔════════════════════════════╗");  // 2칸씩
		System.out.println("  ║  연차 승인 내역 상세 조회  ║");
		System.out.println("  ╚════════════════════════════╝");
		System.out.println();
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println(" NO. |직원번호 | 직원이름 | 연차사용날짜 | 연차사용일수 | 연차승인자 | 연차승인일자");
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println("  1  |        |          |              |              |            |               ");
		System.out.println("──────────────────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println("  1. 연차 승인 내역 수정  2. 연차 승인 내역 삭제  3. 근태 조회 메뉴");
		System.out.println();
		

	}
	
	public void salMain() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║       급여 조회 메뉴      ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1.급여 정보 전체 목록");
		System.out.println("  2.급여 지급 내역 전체 목록");
		System.out.println("  3.메인메뉴");                     
		System.out.println();
		System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		System.out.println("--------------------------------");
	   	System.out.println("     1번 ~ 3번을 선택해주세요.  ");
	   	System.out.println("--------------------------------");
	   	System.out.println();
	}
	
	public void salInfoList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여정보 전체 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("───────────────────────────────────────────");
		System.out.println(" NO. | 직원번호 | 직원이름 | 기본급(호봉)  ");
		System.out.println("───────────────────────────────────────────");
		System.out.println("  1  |          |          |               ");
		System.out.println("───────────────────────────────────────────");
		System.out.println("  2  |          |          |               ");
		System.out.println("───────────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("   1. 개별 조회  2. 급여 조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
		
	}
	
	
	public void salInfoDetail(String emid) {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     급여정보 개별 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  💡 직원번호를 입력하세요 >>  ");
		System.out.println();
		System.out.println("─────────────────────────────────────────────────────────────────────");
		System.out.println(" NO. | 직원번호 | 직원이름 | 기본급(호봉) | 은행명 | 예금주 | 계좌번호");
		System.out.println("─────────────────────────────────────────────────────────────────────");
		System.out.println(" 1   |         |          |              |        |        |         ");
		System.out.println("─────────────────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println();
		System.out.println("  1. 급여 정보 수정  2. 급여 정보 삭제  3. 급여 조회 메뉴");
		System.out.println();
		System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		
	}
	
	
	public void salPayAllList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║    급여 지급 내역 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("────────────────────────────────────");
		System.out.println(" NO. | 직원번호 | 지급일시 |  총급여 ");
		System.out.println("────────────────────────────────────");
		System.out.println(" 1   |         |          |          ");
		System.out.println("────────────────────────────────────");
		System.out.println();
		System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
		System.out.println();
		System.out.println("  1. 개별 조회  2. 급여 조회 메뉴");
	    System.out.println();
	    System.out.println("  💡 선택(숫자 입력) >> ");
	    System.out.println();
		
	}
	
	public void salPayList(String emid) {
		System.out.println("  ╔═════════════════════════════╗");  // 2칸씩
		System.out.println("  ║   급여 지급 내역 개별 조회  ║");
		System.out.println("  ╚═════════════════════════════╝");
		System.out.println();
		System.out.println("  💡 직원번호를 입력하세요 >>  ");
		System.out.println();
		System.out.println("─────────────────────────────────────────────────────────");
		System.out.println(" NO. |직원번호 | 지급일시 | 기본급(호봉) | 상여금 | 총급여 ");
		System.out.println("─────────────────────────────────────────────────────────");
		System.out.println("  1  |        |          |              |        |        ");
		System.out.println("─────────────────────────────────────────────────────────");
		System.out.println("  2  |        |          |              |        |        ");
		System.out.println("─────────────────────────────────────────────────────────");
		System.out.println();
		System.out.println();
		System.out.println("  💡 조회할 번호 선택(숫자 입력) >> ");
		System.out.println();
		
	}
	
	public void salPayDetail() {
		System.out.println("  ╔═════════════════════════════╗");  // 2칸씩
		System.out.println("  ║  급여 지급 내역 상세 조회   ║");
		System.out.println("  ╚═════════════════════════════╝");
		System.out.println();
		System.out.println("──────────────────────────────────────────────────────");
		System.out.println(" NO. |직원번호 | 지급일시 | 기본급(호봉) | 상여금 | 총급여 ");
		System.out.println("──────────────────────────────────────────────────────");
		System.out.println("  1  |        |          |              |        |        ");
		System.out.println("──────────────────────────────────────────────────────");
		System.out.println();
		System.out.println("   1. 급여 지급 내역 수정  2. 급여 지급 내역 삭제  3. 급여 조회 메뉴");
		System.out.println();
		System.out.println("  💡 선택(숫자 입력) >> ");
		System.out.println();
		
		
	}
	
	// 인사 조회메뉴
	public void revView() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     인사 고과 조회 메뉴   ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.println("  1. 평가기록 전체 목록");
		System.out.println("  2. 평가기록 개별 조회");
		System.out.println("  3. 메인메뉴");                     
		System.out.println();
		System.out.print(" 💡 선택(숫자 입력) >> ");
		int input = sc.nextInt();
		System.out.println();
		
	   	
	   	switch(input) {
	   	case 1 : revAllList();  break;
	   	case 2 : revList();  break;
	   	case 3 : pmReader(); break;
	   	default: 
	   		System.out.println("--------------------------------");
	   		System.out.println("     1번 ~ 3번을 선택해주세요.  ");
	   		System.out.println("--------------------------------");
	   		System.out.println();	  	   		
	   	} 

	} // revView end
	
	// 평가 전체 목록
	public void revAllList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     인사고과 전체 목록    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		
		List<ReviewVO> reviewList = rdao.revSelect();
		
		if(reviewList.size() >0) {
			System.out.println("──────────────────────────────────────────────────────────");
			System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
			System.out.println("──────────────────────────────────────────────────────────");
			
			for(ReviewVO list : reviewList) {
				System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
				System.out.println("──────────────────────────────────────────────────────────");
			}
				System.out.println();
				System.out.println(" < 상세조회가 필요하면 아래 메뉴를 선택해주세요. >");
				System.out.println();
				System.out.println("    1. 부서별 조회  2. 직급별 조회");
				System.out.println("    3. 연도별 조회  4. 개별 조회");
				System.out.println("    5. 인사고과 조회 메뉴");
			    System.out.println();
			    System.out.print("    💡 선택(숫자 입력) >> ");
			    int input = sc.nextInt();
			    System.out.println();
			    
			    switch(input) {
			    case 1 : revAllList1(); break;
			    case 2 : revAllList2(); break;
			    case 3 : revAllList3(); break;
//			    case 4 : revLiet(emid); break;
			    case 5 : revView();  break;
			    default :
			    	System.out.println("--------------------------------");
			   		System.out.println("     1번 ~ 5번을 선택해주세요.  ");
			   		System.out.println("--------------------------------");
			   		System.out.println();	
			   		revAllList();
			    }
			
		}else {
			System.out.println("--------------------------------");
			System.out.println("     등록된 평가가 없습니다.    ");
			System.out.println("--------------------------------");
			System.out.println();
			revView();
				
			}
						
		} // revAllList end
		
	    // 부서
		public void revAllList1() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    부서별 인사고과 조회   ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  1. 생산팀(D1)     2. 인사팀(D2)");
			System.out.println("  3. 품질관리팀(D3) 4. 경리팀(D4) ");
			System.out.println();
			System.out.print("  💡 선택(숫자 입력) >> ");
			int input = sc.nextInt();
			System.out.println();
			
			switch(input) {
			case 1 :
				List<ReviewVO> reviewList = rdao.revSelectD("D1");
				
				if(reviewList.size() >0) {
					System.out.println("──────────────────────────────────────────────────────────");
					System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
					System.out.println("──────────────────────────────────────────────────────────");
					
					for(ReviewVO list : reviewList) {
						System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
						System.out.println("──────────────────────────────────────────────────────────");
					}
						System.out.println();
						System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 						
				        System.out.println();  
				        System.out.print("  💡 선택(숫자 입력) >> ");
				        int num = sc.nextInt();
				        System.out.println();
				        
				        switch(num) {
				        	case 1 : break;
				        	case 2 : break;
				        }
					
				}
				break;
			case 2 :
				List<ReviewVO> reviewList1 = rdao.revSelectD("D2");
				
				if(reviewList1.size() >0) {
					System.out.println("──────────────────────────────────────────────────────────");
					System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
					System.out.println("──────────────────────────────────────────────────────────");
					
					for(ReviewVO list : reviewList1) {
						System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
						System.out.println("──────────────────────────────────────────────────────────");
					}
					System.out.println();
					System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
			        System.out.println();
			        System.out.print("  💡 선택(숫자 입력) >> ");
			        System.out.println();
				}
				break;
			case 3 :
				List<ReviewVO> reviewList2 = rdao.revSelectD("D3");
				
				if(reviewList2.size() >0) {
					System.out.println("──────────────────────────────────────────────────────────");
					System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
					System.out.println("──────────────────────────────────────────────────────────");
					
					for(ReviewVO list : reviewList2) {
						System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
						System.out.println("──────────────────────────────────────────────────────────");	
					}
						System.out.println();
						System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
				        System.out.println();
				        System.out.print("  💡 선택(숫자 입력) >> ");
				        System.out.println();
				}
				break;
			case 4 : 
				List<ReviewVO> reviewList3 = rdao.revSelectD("D3");
				
				if(reviewList3.size() >0) {
					System.out.println("──────────────────────────────────────────────────────────");
					System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
					System.out.println("──────────────────────────────────────────────────────────");
					
					for(ReviewVO list : reviewList3) {
						System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
						System.out.println("──────────────────────────────────────────────────────────");
					}
						System.out.println();
						System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
				        System.out.println();
				        System.out.print("  💡 선택(숫자 입력) >> ");
				        System.out.println();
				}
				break;
			default : 
				System.out.println("--------------------------------");
		   		System.out.println("     1번 ~ 4번을 선택해주세요.  ");
		   		System.out.println("--------------------------------");
		   		System.out.println();	
		   		revAllList1();
			}
			
		}
		
		
		// 직급
		public void revAllList2() {
			System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
			System.out.println("  ║    직급별 인사고과 조회   ║");
			System.out.println("  ╚═══════════════════════════╝");
			System.out.println();
			System.out.println("  1. 사원   2. 대리");
			System.out.println("  3. 과장   4. 부장");
			System.out.println();
			System.out.print("  💡 선택(숫자 입력) >> ");
			int input = sc.nextInt();
			System.out.println();
			
			switch(input) {
				case 1 :
					List<ReviewVO> reviewList = rdao.revSelectP("사원");
					
					if(reviewList.size() >0) {
						System.out.println("──────────────────────────────────────────────────────────");
						System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
						System.out.println("──────────────────────────────────────────────────────────");
						
						for(ReviewVO list : reviewList) {
							System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
							System.out.println("──────────────────────────────────────────────────────────");
						}
							System.out.println();
							System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
					        System.out.println();
					        System.out.print("  💡 선택(숫자 입력) >> ");
					        System.out.println();
					}
					break;
				case 2 :
					List<ReviewVO> reviewList1 = rdao.revSelectP("대리");
					
					if(reviewList1.size() >0) {
						System.out.println("──────────────────────────────────────────────────────────");
						System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
						System.out.println("──────────────────────────────────────────────────────────");
						
						for(ReviewVO list : reviewList1) {
							System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
							System.out.println("──────────────────────────────────────────────────────────");
						}
							System.out.println();
							System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
					        System.out.println();
					        System.out.print("  💡 선택(숫자 입력) >> ");
					        System.out.println();
					}
					break;
				case 3 :
					List<ReviewVO> reviewList2 = rdao.revSelectP("과장");
					
					if(reviewList2.size() >0) {
						System.out.println("──────────────────────────────────────────────────────────");
						System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
						System.out.println("──────────────────────────────────────────────────────────");
						
						for(ReviewVO list : reviewList2) {
							System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
							System.out.println("──────────────────────────────────────────────────────────");					
						}
							System.out.println();
							System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
					        System.out.println();
					        System.out.print("  💡 선택(숫자 입력) >> ");
					        System.out.println();
					}
					break;
				case 4 :
					List<ReviewVO> reviewList3 = rdao.revSelectP("부장");
					
					if(reviewList3.size() >0) {
						System.out.println("──────────────────────────────────────────────────────────");
						System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
						System.out.println("──────────────────────────────────────────────────────────");
						
						for(ReviewVO list : reviewList3) {
							System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
							System.out.println("──────────────────────────────────────────────────────────");
						}
							System.out.println();
							System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
					        System.out.println();
					        System.out.print("  💡 선택(숫자 입력) >> ");
					        System.out.println();
					}
					break;
				default :
					System.out.println("--------------------------------");
			   		System.out.println("     1번 ~ 4번을 선택해주세요.  ");
			   		System.out.println("--------------------------------");
			   		System.out.println();	
			   		revAllList2();
			}		
		}
		
		// 연도
	    public void revAllList3() {
	    	System.out.println("  ╔══════════════════════════════╗");  // 2칸씩
			System.out.println("  ║      연도별 인사고과 조회    ║");
			System.out.println("  ╠══════════════════════════════║");
			System.out.println("  ║ 기록은 평가일로부터 3년 유효 ║");
			System.out.println("  ╚══════════════════════════════╝");
			System.out.println();
			System.out.print("  💡 연도를 입력하세요(숫자 입력) >>  ");
			String input = sc.next();
			
			List<ReviewVO> reviewList = rdao.revSelectY(input);
			
			if(reviewList.size() >0) {
				System.out.println("──────────────────────────────────────────────────────────");
				System.out.println(" NO | 직원번호 | 부서번호 | 직급 | 평가등급 |  평가일시   ");
				System.out.println("──────────────────────────────────────────────────────────");
				
				for(ReviewVO list : reviewList) {
					System.out.printf("  %d |   %s  |    %s    | %s |     %s    | %s%n",list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getGrade(),list.getEvalDate());
					System.out.println("──────────────────────────────────────────────────────────");
				}
					System.out.println();
					System.out.println("  1. 개별 조회  2. 인사고과 조회 메뉴"); 
			        System.out.println();
			        System.out.print("  💡 선택(숫자 입력) >> ");
			        System.out.println();
			}else {
				System.out.println("--------------------------------");
		   		System.out.println("   데이터가 존재하지 않습니다.  ");
		   		System.out.println("--------------------------------");
		   		System.out.println();	
				
			}

	    }
		
	
	// 개별조회
	public void revList() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     인사고과 개별 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.print("  💡 직원번호를 입력하세요 >>  ");
		String input = sc.next();
		System.out.println();
		
		List<ReviewVO> reviewList = rdao.revSelect(input);
		
		if(reviewList.size() >0) {
				System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── ");
				System.out.println(" NO.| 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 |      비고    |  평가일시");
				System.out.println("──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			
			for(ReviewVO list : reviewList) {
				System.out.printf("  %d |   %s  |    %s    | %s |    %d    |    %d    |   %d   |   %d   |    %d    |   %d  |    %s     |     %s     | %s  ",
						list.getReno(),list.getEmid(),list.getDno(),list.getPosition(),list.getEval1(),list.getEval2(),
						list.getEval3(),list.getEval4(),list.getEval5(),list.getEvalTot(),list.getGrade(),list.getRemark(),list.getEvalDate());
				System.out.println("────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── ");
				System.out.println();
				System.out.println("  1. 개별 조회   2. 인사고과 조회 메뉴"); 
		        System.out.println();
		        System.out.print("  💡 선택 >> ");
		        int num = sc.nextInt();
		        System.out.println();
		        
		        switch(num) {
		        	case 1 : revDetail(); break;
		        	case 2 : revView(); break;
		        }
			}
			
		}else {
			System.out.println("--------------------------------");
	   		System.out.println("  존재하지 않는 직원번호입니다. ");
	   		System.out.println("--------------------------------");
	   		System.out.println();
	   		revView();
		}
				
	}
	
	public void revDetail() {
		System.out.println("  ╔═══════════════════════════╗");  // 2칸씩
		System.out.println("  ║     인사고과 상세 조회    ║");
		System.out.println("  ╚═══════════════════════════╝");
		System.out.println();
		System.out.print("  💡 조회할 번호 선택(숫자 입력) >> ");
		int input = sc.nextInt();
		System.out.println();	
		
		ReviewVO revo = rdao.revSelect(input);
		
		if(revo !=null) {
			System.out.println("───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── ");
			System.out.println(" NO.| 직원번호 | 부서번호 | 직급 | 관리능력 | 유대관계 | 책임감 | 근면성 | 업무지식 | 총점수 | 평가등급 |      비고    |  평가일시");
			System.out.println("──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────");
			System.out.printf("  %d |   %s  |    %s    | %s |    %d    |    %d    |   %d   |   %d   |    %d    |   %d  |    %s     |     %s     | %s  ",
					revo.getReno(),revo.getEmid(),revo.getDno(),revo.getPosition(),revo.getEval1(),revo.getEval2(),
					revo.getEval3(),revo.getEval4(),revo.getEval5(),revo.getEvalTot(),revo.getGrade(),revo.getRemark(),revo.getEvalDate());
			System.out.println("────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────── ");
			System.out.println();
			System.out.println("  1. 평가 수정  2. 평가 삭제  3. 인사고과 조회 메뉴");
			System.out.println();
			System.out.print("  💡 선택(숫자 입력) >> ");
			int num = sc.nextInt();
			System.out.println();
			
			HrAdminMain hram = new HrAdminMain();
			switch(num) {
			case 1 : hram.revModify(revo);  break;
			case 2 : hram.revRemove(input); break;
			case 3 : revView(); break;
			default :
				System.out.println("--------------------------------");
		   		System.out.println("     1번 ~ 3번을 선택해주세요.  ");
		   		System.out.println("--------------------------------");
		   		System.out.println();	  	   		
			}
		
		} // else end
		
	} // detail end
	
}// class end