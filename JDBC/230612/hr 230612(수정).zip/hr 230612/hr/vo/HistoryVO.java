package hr.vo;

import java.util.Date;

public class HistoryVO {
	private String emid;		//	직원번호
	private String name;		//	직원이름
	private String dno;			//	부서번호
	private String dname;		//  부서이름
	private String position;	//	직급	
	private String leaveStart; 	//	시작날짜       yyyy-mm-dd
	private String leaveFin;		//	종료날짜  yyyy-mm-dd
	private String remark;		//	구분
//	private Date departStart;	//	부서시작날짜 
//	private Date departMove;	//	부서이동날짜
//	private Date revom;			//	승진날짜	
	
	public String getEmid() {
		return emid;
	}
	public void setEmid(String emid) {
		this.emid = emid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDeno() {
		return dno;
	}
	public void setDeno(String deno) {
		this.dno = deno;
	}
	public String getLeaveStart() {
		return leaveStart;
	}
	public void setLeaveStart(String leaveStart) {
		this.leaveStart = leaveStart;
	}
	public String getLeaveFin() {
		return leaveFin;
	}
	public void setLeaveFin(String leaveFin) {
		this.leaveFin = leaveFin;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	
	
}